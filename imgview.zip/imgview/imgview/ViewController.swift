//
//  ViewController.swift
//  imgview
//
//  Created by MACOS on 6/7/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate,UITableViewDataSource,UITableViewDelegate {
    
    var final = [Any]()
    
    @IBOutlet var tbl: UITableView!

    @IBOutlet var txt: UITextField!
    @IBOutlet weak var img: UIImageView!
    
    var imgpicker = UIImagePickerController();
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let str = String("http://localhost/demo/select.php")
        let url = URL(string: str!)
        let request = URLRequest(url: url!)
        let session = URLSession.shared
        let datatask = session.dataTask(with: request, completionHandler: {(data,res,err) in
            
           // let str1 = String(data: data!, encoding: String.Encoding.utf8);
            //print(str1!)
            
            DispatchQueue.main.sync {
                do
                {
                    let dic = try JSONSerialization.jsonObject(with: data!, options: []) as! [Any]
                    
                    for item in dic
                    {
                        self.final.append(item)
                        print(self.final)
                        self.tbl.reloadData()
                    }
                }
                catch
                {
                    
                }
            }
            
        })
            datatask.resume()

        
    }

    @IBAction func btnact(_ sender: Any) {
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary){
            
            imgpicker.delegate = self;
            imgpicker.sourceType = .photoLibrary;
            imgpicker.allowsEditing = false;
            self.present(imgpicker, animated: true, completion: nil)
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        img.image = info[UIImagePickerControllerOriginalImage] as? UIImage
        
                
        self.dismiss(animated: true, completion: nil)
    }
    
  

    @IBAction func btnInsert(_ sender: Any) {
        let url = URL(string: "http://localhost/demo/image.php");
        
        let img1 = img.image;
        let imgdata = UIImageJPEGRepresentation(img1!, 1.0);
        let base64 = imgdata?.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters);
        
        let param = String("name=\(txt.text!)&image=\(base64!)")
        
        let len = param?.characters.count
        
        let dt = param?.data(using: String.Encoding.utf8)
        
        var request = URLRequest(url: url!);
        //var bodydata = "image=\(base64string!)";
        request.addValue(String(describing: len), forHTTPHeaderField: "Content-Length")

        request.httpMethod = "POST";
        request.httpBody = dt
        let session = URLSession.shared;
        let datatask = session.dataTask(with: request, completionHandler: {(data1,res,err) in
            
            let str = String(data: data1!, encoding: String.Encoding.utf8);
            print(str!);
            //self.tbl.reloadData()
            
        })
    
        datatask.resume();

    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return final.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        
        let dicfinal = final[indexPath.row] as! [String:Any]
        
        // Retrive image from database
        var img1:String = ""
        let path = dicfinal["image"] as? String;
        let str = "http://localhost/demo/" + path!
        img1.append(str)
        
        let url = URL(string: str)
        
        do{
            let data = try Data(contentsOf: url!)
            //print(data)
            
            cell?.imageView?.image = UIImage(data: data);
            
        }
        catch
        {
            
        }

        cell?.textLabel?.text = dicfinal["name"] as! String
        return cell!
    }

}












