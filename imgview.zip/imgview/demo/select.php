<?php
    
    $con=new mysqli("localhost","root","","demo");
    
//    $email = $_POST['user_email'];
    //$password = $_POST['user_password'];
    
    
    $qu="SELECT * FROM Category_master";
    
    $pp=$con->query($qu);
    
    while($ff=$pp->fetch_object())
    {
        $qq[]=$ff;
    }
    echo json_encode($qq);
    
    ?>
