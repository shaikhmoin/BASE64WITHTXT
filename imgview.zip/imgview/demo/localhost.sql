-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 22, 2017 at 09:37 AM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `CHIRAG`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_add`
--

CREATE TABLE IF NOT EXISTS `tbl_add` (
  `ID` int(11) NOT NULL,
  `Name` varchar(10) NOT NULL,
  `Address` varchar(10) NOT NULL,
  `Mobile` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_add`
--

INSERT INTO `tbl_add` (`ID`, `Name`, `Address`, `Mobile`) VALUES
(1, 'Chirag', 'Surat', '9601674416'),
(2, 'Milan', 'Anand', '7788996655'),
(4, 'Parth', 'Surat', '7744885577'),
(5, 'Samir', 'Mumbai', '8855885522'),
(6, 'Purav', 'Navsari', '8885552221');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_add`
--
ALTER TABLE `tbl_add`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_add`
--
ALTER TABLE `tbl_add`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;--
-- Database: `Car`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_reg`
--

CREATE TABLE IF NOT EXISTS `tbl_reg` (
  `Reg_id` int(11) NOT NULL,
  `User_name` varchar(10) NOT NULL,
  `Password` varchar(10) NOT NULL,
  `Address` varchar(10) NOT NULL,
  `Mobile` varchar(10) NOT NULL,
  `Email_id` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_reg`
--

INSERT INTO `tbl_reg` (`Reg_id`, `User_name`, `Password`, `Address`, `Mobile`, `Email_id`) VALUES
(1, 'Chirag', '3331212', 'Surat', '9601674416', 'chiraggandhi81@gmail'),
(12, 'key', 'ldvmnkldnc', 'njcnjzxcnj', 'njkcndsajk', 'njkcndsajkc his');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_reg`
--
ALTER TABLE `tbl_reg`
  ADD PRIMARY KEY (`Reg_id`),
  ADD UNIQUE KEY `Email_id` (`Email_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_reg`
--
ALTER TABLE `tbl_reg`
  MODIFY `Reg_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;--
-- Database: `CarRental`
--

-- --------------------------------------------------------

--
-- Table structure for table `Car_Detail`
--

CREATE TABLE IF NOT EXISTS `Car_Detail` (
  `Car_Id` int(3) NOT NULL,
  `Car_Name` varchar(20) NOT NULL,
  `Car_No` varchar(10) NOT NULL,
  `Car_Type` int(3) NOT NULL,
  `Car_Seat` int(3) NOT NULL,
  `Car_Rate` varchar(10) NOT NULL,
  `Car_AC` varchar(10) NOT NULL,
  `Car_Location` varchar(50) NOT NULL,
  `Car_Image` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Car_Detail`
--

INSERT INTO `Car_Detail` (`Car_Id`, `Car_Name`, `Car_No`, `Car_Type`, `Car_Seat`, `Car_Rate`, `Car_AC`, `Car_Location`, `Car_Image`) VALUES
(1, 'Toyota FJ Cruiser', 'GJ05', 1, 6, '10000', 'YES', 'Adajan', '1.jpg'),
(2, 'Dodge Nitro', 'GJ03', 1, 6, '10000', 'YES', 'KatarGaam', '2.jpg'),
(3, 'Mazda MX-5,', 'GJ03', 5, 2, '12000', 'YES', 'Dabholi', '3.jpg'),
(4, 'Porsche 911', 'GJ01', 5, 2, '12000', 'YES', 'Varachha', '4.jpg'),
(5, 'Porsche 911', 'GJ01', 3, 2, '12000', 'YES', 'Yogi Chowk', '5.jpg'),
(6, 'Porsche 911', 'GJ01', 3, 2, '12000', 'YES', 'Simada', '6.jpg'),
(7, 'Porsche 911', 'GJ01', 2, 2, '12000', 'YES', 'Jakatnaka ', '6.jpg'),
(8, 'Porsche 911', 'GJ01', 2, 2, '12000', 'YES', 'Pasodara', '6.jpg'),
(9, 'Dodge Nitro', 'GJ03', 2, 6, '10000', 'YES', 'Hirabag', '2.jpg'),
(10, 'Dodge Nitro', 'GJ03', 1, 6, '10000', 'YES', 'Kapodra', '2.jpg'),
(11, 'Dodge Nitro', 'GJ03', 2, 6, '10000', 'YES', '', '2.jpg'),
(12, 'Dodge Nitro', 'GJ03', 1, 6, '10000', 'YES', '', '2.jpg'),
(13, 'Dodge Nitro', 'GJ03', 4, 6, '10000', 'YES', '', '2.jpg'),
(14, 'Dodge Nitro', 'GJ03', 4, 6, '10000', 'YES', '', '2.jpg'),
(15, 'Dodge Nitro', 'GJ03', 5, 6, '10000', 'YES', '', '2.jpg'),
(16, 'Dodge Nitro', 'GJ03', 1, 6, '10000', 'YES', '', '2.jpg'),
(17, 'Dodge Nitro', 'GJ03', 1, 6, '10000', 'YES', '', '2.jpg'),
(18, 'Dodge Nitro', 'GJ03', 5, 6, '10000', 'YES', '', '2.jpg'),
(19, 'Dodge Nitro', 'GJ03', 1, 6, '10000', 'YES', '', '2.jpg'),
(20, 'Dodge Nitro', 'GJ03', 1, 6, '10000', 'YES', '', '2.jpg'),
(21, 'Dodge Nitro', 'GJ03', 6, 6, '10000', 'YES', '', '2.jpg'),
(22, 'Dodge Nitro', 'GJ03', 6, 6, '10000', 'YES', '', '2.jpg'),
(23, 'Dodge Nitro', 'GJ03', 1, 6, '10000', 'YES', '', '2.jpg'),
(24, 'Dodge Nitro', 'GJ03', 5, 6, '10000', 'YES', '', '2.jpg'),
(25, 'Dodge Nitro', 'GJ03', 1, 6, '10000', 'YES', '', '2.jpg'),
(26, 'Dodge Nitro', 'GJ03', 2, 6, '10000', 'YES', '', '2.jpg'),
(27, 'Dodge Nitro', 'GJ03', 2, 6, '10000', 'YES', '', '2.jpg'),
(28, 'Dodge Nitro', 'GJ03', 3, 6, '10000', 'YES', '', '2.jpg'),
(29, 'Dodge Nitro', 'GJ03', 1, 6, '10000', 'YES', '', '2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `Car_Type`
--

CREATE TABLE IF NOT EXISTS `Car_Type` (
  `Car_Type_Id` int(3) NOT NULL,
  `Car_Type_Name` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Car_Type`
--

INSERT INTO `Car_Type` (`Car_Type_Id`, `Car_Type_Name`) VALUES
(1, 'Sedans & Hatchbacks'),
(2, 'SUVs '),
(3, 'Luxury Vehicles'),
(4, 'Electric Cars & Hybr'),
(5, 'Sports Cars'),
(6, 'Trucks & Full-size V');

-- --------------------------------------------------------

--
-- Table structure for table `Customer_Regitration`
--

CREATE TABLE IF NOT EXISTS `Customer_Regitration` (
  `Cust_id` int(3) NOT NULL,
  `Cust_Fname` varchar(20) NOT NULL,
  `Cust_Lname` varchar(20) NOT NULL,
  `Cust_Email` varchar(100) NOT NULL,
  `Cust_Password` varchar(20) NOT NULL,
  `Cust_Contact` varchar(10) NOT NULL,
  `Cust_Address` text NOT NULL,
  `Cust_Image` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Customer_Regitration`
--

INSERT INTO `Customer_Regitration` (`Cust_id`, `Cust_Fname`, `Cust_Lname`, `Cust_Email`, `Cust_Password`, `Cust_Contact`, `Cust_Address`, `Cust_Image`) VALUES
(1, 'Vishal', 'Vaghasiya', 'vaghasiya908@gmail.com', '123456', '9725992973', 'Surat', 'vishal.jpg'),
(2, 'as', 'as', 'aa@gmail.com', 'asd', '4563217890', '', ''),
(3, 'VISHAL', 'VAGHASIYA', 'vaghasiya@gmail.com', 'asd', '1236547890', '', 'images/584fa02fbb668.png'),
(4, 'Vishal', 'vaghasiya', 'vaghasiya907@gmail.com', '123456', '9725992972', '', 'images/584fa1c15b4bc.png');

-- --------------------------------------------------------

--
-- Table structure for table `Order_Booking`
--

CREATE TABLE IF NOT EXISTS `Order_Booking` (
  `Book_Id` int(3) NOT NULL,
  `Car_Id` int(3) NOT NULL,
  `Cust_Id` int(3) NOT NULL,
  `Booking_FromDate` date NOT NULL,
  `Booking_ToDate` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Order_Booking`
--

INSERT INTO `Order_Booking` (`Book_Id`, `Car_Id`, `Cust_Id`, `Booking_FromDate`, `Booking_ToDate`) VALUES
(12, 1, 8, '2016-11-18', '2016-11-19'),
(13, 1, 8, '2016-11-18', '2016-11-19'),
(14, 1, 1, '2016-12-29', '2016-12-30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Car_Detail`
--
ALTER TABLE `Car_Detail`
  ADD PRIMARY KEY (`Car_Id`);

--
-- Indexes for table `Car_Type`
--
ALTER TABLE `Car_Type`
  ADD PRIMARY KEY (`Car_Type_Id`);

--
-- Indexes for table `Customer_Regitration`
--
ALTER TABLE `Customer_Regitration`
  ADD PRIMARY KEY (`Cust_id`),
  ADD UNIQUE KEY `Cust_Email` (`Cust_Email`);

--
-- Indexes for table `Order_Booking`
--
ALTER TABLE `Order_Booking`
  ADD PRIMARY KEY (`Book_Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Car_Detail`
--
ALTER TABLE `Car_Detail`
  MODIFY `Car_Id` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `Car_Type`
--
ALTER TABLE `Car_Type`
  MODIFY `Car_Type_Id` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `Customer_Regitration`
--
ALTER TABLE `Customer_Regitration`
  MODIFY `Cust_id` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `Order_Booking`
--
ALTER TABLE `Order_Booking`
  MODIFY `Book_Id` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;--
-- Database: `CarRentalDB`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblAddCarDetail`
--

CREATE TABLE IF NOT EXISTS `tblAddCarDetail` (
  `car_id` int(11) NOT NULL,
  `sp_id` int(11) NOT NULL,
  `car_type_id` int(11) NOT NULL,
  `car_name` int(11) NOT NULL,
  `car_capacity` int(11) NOT NULL,
  `car_rate` int(11) NOT NULL,
  `car_status` varchar(5) NOT NULL,
  `car_latitude` varchar(100) NOT NULL,
  `car_longitute` varchar(100) NOT NULL,
  `car_image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblBooking`
--

CREATE TABLE IF NOT EXISTS `tblBooking` (
  `booking_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `car_id` int(11) NOT NULL,
  `sp_id` int(11) NOT NULL,
  `booking_date` varchar(20) NOT NULL,
  `booking_time` varchar(20) NOT NULL,
  `booking_status` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblCarType`
--

CREATE TABLE IF NOT EXISTS `tblCarType` (
  `car_type_id` int(11) NOT NULL,
  `car_type_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblReview`
--

CREATE TABLE IF NOT EXISTS `tblReview` (
  `review_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `bookind_id` int(11) NOT NULL,
  `description` varchar(250) NOT NULL,
  `rating` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblServiceProviderRegistration`
--

CREATE TABLE IF NOT EXISTS `tblServiceProviderRegistration` (
  `sp_id` int(11) NOT NULL,
  `sp_name` varchar(20) NOT NULL,
  `sp_contact` varchar(12) NOT NULL,
  `sp_email` varchar(30) NOT NULL,
  `sp_address` varchar(80) NOT NULL,
  `sp_image` varchar(200) NOT NULL,
  `sp_status_pwd` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblUserRegistration`
--

CREATE TABLE IF NOT EXISTS `tblUserRegistration` (
  `user_id` int(11) NOT NULL,
  `user_fnm` varchar(50) NOT NULL,
  `user_lnm` varchar(15) NOT NULL,
  `user_address` varchar(50) NOT NULL,
  `user_email` varchar(30) NOT NULL,
  `user_password` varchar(30) NOT NULL,
  `user_contact` varchar(12) NOT NULL,
  `user_image` varchar(200) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblUserRegistration`
--

INSERT INTO `tblUserRegistration` (`user_id`, `user_fnm`, `user_lnm`, `user_address`, `user_email`, `user_password`, `user_contact`, `user_image`) VALUES
(5, 'Chirag', 'Gajera', 'Surat', 'milan@mj.com', 'milan', '0123456789', NULL),
(8, 'Mitesh', 'Tank', 'Surat', 'mitesh@tank.co.uk', 'Mitesh@123', '1234567890', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblAddCarDetail`
--
ALTER TABLE `tblAddCarDetail`
  ADD PRIMARY KEY (`car_id`);

--
-- Indexes for table `tblBooking`
--
ALTER TABLE `tblBooking`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `tblCarType`
--
ALTER TABLE `tblCarType`
  ADD PRIMARY KEY (`car_type_id`);

--
-- Indexes for table `tblReview`
--
ALTER TABLE `tblReview`
  ADD PRIMARY KEY (`review_id`);

--
-- Indexes for table `tblServiceProviderRegistration`
--
ALTER TABLE `tblServiceProviderRegistration`
  ADD PRIMARY KEY (`sp_id`);

--
-- Indexes for table `tblUserRegistration`
--
ALTER TABLE `tblUserRegistration`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblAddCarDetail`
--
ALTER TABLE `tblAddCarDetail`
  MODIFY `car_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tblBooking`
--
ALTER TABLE `tblBooking`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tblCarType`
--
ALTER TABLE `tblCarType`
  MODIFY `car_type_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tblReview`
--
ALTER TABLE `tblReview`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tblServiceProviderRegistration`
--
ALTER TABLE `tblServiceProviderRegistration`
  MODIFY `sp_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tblUserRegistration`
--
ALTER TABLE `tblUserRegistration`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;--
-- Database: `ChatOn`
--

-- --------------------------------------------------------

--
-- Table structure for table `sender`
--

CREATE TABLE IF NOT EXISTS `sender` (
  `id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `S_mob` int(10) NOT NULL,
  `message` varchar(50) NOT NULL,
  `img` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sender`
--
ALTER TABLE `sender`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `sender`
--
ALTER TABLE `sender`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;--
-- Database: `Fruit_Guide`
--

-- --------------------------------------------------------

--
-- Table structure for table `Diet_Chart`
--

CREATE TABLE IF NOT EXISTS `Diet_Chart` (
  `Diet_id` int(11) NOT NULL,
  `Nutrition_ID` varchar(10) NOT NULL,
  `Diseases_id` varchar(10) NOT NULL,
  `Chart_Name` varchar(20) NOT NULL,
  `Description` varchar(200) NOT NULL,
  `Chart_image` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Diet_Chart`
--

INSERT INTO `Diet_Chart` (`Diet_id`, `Nutrition_ID`, `Diseases_id`, `Chart_Name`, `Description`, `Chart_image`) VALUES
(10, '1', '3', 'check', 'Cvxzvzxxcvzcx', 'http://localhost/Fruit_Guide/uploads/IMAGE_14800572278.jpg'),
(11, '1', '1', 'fdfdfdf', 'Fdfdfasf', 'http://localhost/Fruit_Guide/uploads/IMAGE_14800572278.jpg'),
(12, '1', '3', 'Fruit', 'Fruit Is good for health.', 'http://localhost/Fruit_Guide/uploads/IMAGE_14809178048.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `Get_Diseases`
--

CREATE TABLE IF NOT EXISTS `Get_Diseases` (
  `Diseases_id` int(11) NOT NULL,
  `Diseases_name` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Get_Diseases`
--

INSERT INTO `Get_Diseases` (`Diseases_id`, `Diseases_name`) VALUES
(1, 'fevar'),
(2, 'Maleria'),
(3, 'Cancer'),
(4, 'Brain'),
(5, 'Kidney');

-- --------------------------------------------------------

--
-- Table structure for table `Get_Fruitguide`
--

CREATE TABLE IF NOT EXISTS `Get_Fruitguide` (
  `Fruitguide_id` int(11) NOT NULL,
  `Diseases_Name` varchar(100) NOT NULL,
  `Fruit_name` varchar(50) NOT NULL,
  `Fruit_detail` varchar(200) NOT NULL,
  `Nutrition_id` varchar(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Get_Fruitguide`
--

INSERT INTO `Get_Fruitguide` (`Fruitguide_id`, `Diseases_Name`, `Fruit_name`, `Fruit_detail`, `Nutrition_id`) VALUES
(1, '', 'apple', 'apple is very good fruit', '0'),
(7, '', 'Mango', 'Mango', '0'),
(8, '', 'Orange', 'Orange', '0'),
(19, 'Kidney', 'cherry', 'Cherry', 'chirag'),
(20, 'Maleria', 'jinal', 'stroberry', '1'),
(21, 'Brain', 'guava', 'njkxcbgxdkbcfhsdasnj', '1');

-- --------------------------------------------------------

--
-- Table structure for table `Nutrition_Reg`
--

CREATE TABLE IF NOT EXISTS `Nutrition_Reg` (
  `Nutrition_ID` int(20) NOT NULL,
  `Nutrition_type_id` varchar(10) NOT NULL,
  `Nutrition_name` varchar(50) NOT NULL,
  `Qulification` varchar(50) NOT NULL,
  `Mobile` varchar(11) NOT NULL,
  `Address` varchar(150) NOT NULL,
  `Password` varchar(15) NOT NULL,
  `Status` varchar(15) NOT NULL,
  `Experience` varchar(10) NOT NULL,
  `nutrition_image` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Nutrition_Reg`
--

INSERT INTO `Nutrition_Reg` (`Nutrition_ID`, `Nutrition_type_id`, `Nutrition_name`, `Qulification`, `Mobile`, `Address`, `Password`, `Status`, `Experience`, `nutrition_image`) VALUES
(1, 'Fat', 'CHIRAG', 'MSC', '9601674416', 'Surat', '3331212', 'Available', '5year', 'http://localhost/Fruit_Guide/uploads/IMAGE_1868161986.jpg'),
(2, 'Protein', 'JINAL', 'MSC', '4455221133', 'MAHUVA', '3331212', 'Avilable', '5year', 'http://localhost/Fruit_Guide/uploads/IMAGE_1868161986.jpg'),
(3, 'Vitamins', 'MILAN', 'MSC', '8989898989', 'Surat', '3331212', 'Available', '3year', 'http://localhost/Fruit_Guide/uploads/IMAGE_1868161986.jpg'),
(4, 'Water', 'MITESH', 'MSC', '4544545545', 'Surat', '3331212', 'Pending', '5year', 'http://localhost/Fruit_Guide/uploads/IMAGE_1868161986.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `Question_answer`
--

CREATE TABLE IF NOT EXISTS `Question_answer` (
  `Chat_id` int(20) NOT NULL,
  `User_id` varchar(20) NOT NULL,
  `Question_description` varchar(100) NOT NULL,
  `Nutrition_id` varchar(20) NOT NULL,
  `Answer` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Question_answer`
--

INSERT INTO `Question_answer` (`Chat_id`, `User_id`, `Question_description`, `Nutrition_id`, `Answer`) VALUES
(4, '1', 'howru', '2', 'Fine'),
(5, '1', 'howru', '4', 'Fine'),
(6, '2', 'howru', '1', 'Me also fine'),
(7, '2', 'whichcity', '1', 'Mahuva'),
(8, '1', 'where', '2', 'Bardoli'),
(9, '1', 'whichcity', '4', 'Bhavnagar');

-- --------------------------------------------------------

--
-- Table structure for table `nutrition_types`
--

CREATE TABLE IF NOT EXISTS `nutrition_types` (
  `nutrition_id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nutrition_types`
--

INSERT INTO `nutrition_types` (`nutrition_id`, `name`) VALUES
(1, 'Carbohydrates'),
(2, 'Protein'),
(3, 'Fat'),
(4, 'Vitamins'),
(5, 'Minerals'),
(6, 'Water');

-- --------------------------------------------------------

--
-- Table structure for table `userreg`
--

CREATE TABLE IF NOT EXISTS `userreg` (
  `User_ID` int(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `User_Name` varchar(20) NOT NULL,
  `Email_ID` varchar(50) NOT NULL,
  `Mobile` varchar(11) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Diseases_Type` varchar(20) NOT NULL,
  `user_image` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userreg`
--

INSERT INTO `userreg` (`User_ID`, `password`, `User_Name`, `Email_ID`, `Mobile`, `Address`, `Diseases_Type`, `user_image`) VALUES
(1, '3331212', 'CHIRAG', 'chiraggandhi81@gmail.com', '9601674416', 'Surat', 'Water', ''),
(2, '3331212', 'JINAL', 'jinalkshah@gmail.com', '8899885522', 'Mahuva', 'Water', ''),
(3, '3331212', 'MEET', 'meet@gmail.com', '4455221122', 'Surat', 'pressure', 'http://localhost/Fruit_Guide/uploads/IMAGE_1869838238.jpg'),
(4, '3331212', 'MITESH', 'tankmitesh115@gmail.com', '7777888800', 'Surat', 'FAT', ''),
(5, '3331212', 'Samir', 'samir@gmail.com', '7788996655', 'Surat', 'Kidney', 'http://localhost/Fruit_Guide/uploads/IMAGE_14785810676.jpg'),
(6, '3331212', 'Shefali', 'shefali@gmail.com', '8899665522', 'Surat', 'brain', 'http://localhost/Fruit_Guide/uploads/IMAGE_14785883654.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Diet_Chart`
--
ALTER TABLE `Diet_Chart`
  ADD PRIMARY KEY (`Diet_id`);

--
-- Indexes for table `Get_Diseases`
--
ALTER TABLE `Get_Diseases`
  ADD PRIMARY KEY (`Diseases_id`);

--
-- Indexes for table `Get_Fruitguide`
--
ALTER TABLE `Get_Fruitguide`
  ADD PRIMARY KEY (`Fruitguide_id`);

--
-- Indexes for table `Nutrition_Reg`
--
ALTER TABLE `Nutrition_Reg`
  ADD PRIMARY KEY (`Nutrition_ID`),
  ADD KEY `Nutrition_type_id` (`Nutrition_type_id`);

--
-- Indexes for table `Question_answer`
--
ALTER TABLE `Question_answer`
  ADD PRIMARY KEY (`Chat_id`);

--
-- Indexes for table `nutrition_types`
--
ALTER TABLE `nutrition_types`
  ADD PRIMARY KEY (`nutrition_id`);

--
-- Indexes for table `userreg`
--
ALTER TABLE `userreg`
  ADD PRIMARY KEY (`User_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Diet_Chart`
--
ALTER TABLE `Diet_Chart`
  MODIFY `Diet_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `Get_Diseases`
--
ALTER TABLE `Get_Diseases`
  MODIFY `Diseases_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `Get_Fruitguide`
--
ALTER TABLE `Get_Fruitguide`
  MODIFY `Fruitguide_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `Nutrition_Reg`
--
ALTER TABLE `Nutrition_Reg`
  MODIFY `Nutrition_ID` int(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `Question_answer`
--
ALTER TABLE `Question_answer`
  MODIFY `Chat_id` int(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `nutrition_types`
--
ALTER TABLE `nutrition_types`
  MODIFY `nutrition_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `userreg`
--
ALTER TABLE `userreg`
  MODIFY `User_ID` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;--
-- Database: `MANNN`
--

-- --------------------------------------------------------

--
-- Table structure for table `catagory_tbl`
--

CREATE TABLE IF NOT EXISTS `catagory_tbl` (
  `catagory_id` varchar(30) NOT NULL,
  `catagory_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `catagory_tbl`
--

INSERT INTO `catagory_tbl` (`catagory_id`, `catagory_name`) VALUES
('BW_Jeans', 'Jeans'),
('P&T', 'Polos & Tees'),
('TW_Shirts', 'Shirts');

-- --------------------------------------------------------

--
-- Table structure for table `product_jeans_tbl`
--

CREATE TABLE IF NOT EXISTS `product_jeans_tbl` (
  `product_sku` varchar(20) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `product_brand` varchar(30) NOT NULL,
  `product_style` varchar(20) NOT NULL,
  `product_size` varchar(20) NOT NULL,
  `product_price` varchar(20) NOT NULL,
  `product_offer` varchar(20) NOT NULL,
  `product_info` varchar(1000) NOT NULL,
  `product_img` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_jeans_tbl`
--

INSERT INTO `product_jeans_tbl` (`product_sku`, `product_name`, `product_brand`, `product_style`, `product_size`, `product_price`, `product_offer`, `product_info`, `product_img`) VALUES
('101SF01', 'JJIGLENN JJORIGINAL GE 988 NOOS SLIM FIT JEANS', 'Jack & Jones', 'Slim Fit', '30,32,34,36', '3500', '', 'Slim fit Glenn\r\nAn updated slim fit with a tapered leg that always comes with stretch. The fit is narrow and lean through the thigh without feeling tight. Glenn is for guys who like their jeans slim, not skinny.', 'product_img/101SF01.jpg'),
('101SF02', 'TIM PAGE BL 739 SLIM FIT JEANS', 'Jack & Jones', 'Slim Fit', '30,32,34,36', '4500', '12% OFF', 'Stonewashed\r\nStonewashed denim is exactly what it says: denim that is washed with stones. The rough surface of the pumice stones bashes the denim, which wears off the indigo and makes the white core of the yarn visible. The treatment makes your denim soft and gives it a naturally faded look.\r\n\r\nHandmade details\r\nThese jeans are finished by hand with details such as hand scraping or handmade rips and repairs. This meticulous finishing is typical for JACK & JONES and sets the jeans apart from the industrially produced fashion that is typical of today.\r\n98% Cotton, 2% Elastane\r\nMachine Wash, half load, short spin at 30°C\r\nDo Not Bleach\r\nNo use of dryer\r\nHang Dry\r\nLow temp. iron. Highest temp. 100°C\r\nDry clean (no Trichloroethylene)', 'product_img/101SF02.jpg'),
('101SJ01', 'JJILIAM JJORIGINAL AM 095 SKINNY FIT', 'Jack & Jones', 'Skinny', '30,32,34,36', '1999', '10% OFF', 'Skinny Fit Liam\r\nThe skinniest fit we’ve got. Liam will give you that sharp, body-conscious silhouette that comes with a super tight fit. It stretches in all the right places and is cut for an overall close fit.\r\n85% Cotton, 13% Polyester, 2% Elastane\r\nMachine Wash at max 30°C under gentle wash programme\r\nDo Not Bleach\r\nNo use of dryer\r\nHang Dry\r\nLow temp. iron. Highest temp. 100°C\r\nDo not dry clean', 'product_img/101SJ01.jpg'),
('101SJ02', 'LIAM ORIGINAL JJ 989 SKINNY FIT JEANS', 'Jack & Jones', 'Skinny', '30,32,34,36', '2499', '5% OFF', '- Skinny cut for a super tight silhouette\r\n- Loads of stretch for full range of motion\r\n- Unique handmade rips and repairs\r\n- The model is wearing a size 31/32 and is 187 cm tall\r\n- JACK & JONES JEANS INTELLIGENCE', 'product_img/101SJ02.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `product_shirts`
--

CREATE TABLE IF NOT EXISTS `product_shirts` (
  `product_sku` varchar(50) NOT NULL,
  `product_cat` varchar(50) NOT NULL,
  `product_brand` varchar(50) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `product_size` varchar(20) NOT NULL,
  `product_qty` varchar(20) NOT NULL,
  `product_price` varchar(20) NOT NULL,
  `product_info` varchar(500) NOT NULL,
  `product_offer` varchar(20) NOT NULL,
  `product_img` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_shirts`
--

INSERT INTO `product_shirts` (`product_sku`, `product_cat`, `product_brand`, `product_name`, `product_size`, `product_qty`, `product_price`, `product_info`, `product_offer`, `product_img`) VALUES
('101ST1', 'Shirts', 'Jack & Jones', 'Checked Casual Shirt', 'S,M,L,XL', '7,11,5,9', '2199', 'Get your fix of checks shirt with from Jack and Jones.The forever trendy casual navy shirt is a must have for all the fashion enthusiasts . Style this with a pair of slim fit jeans and cool bomber jacket and trainers.This slim fit shirt is cut to fit to perfection. Style it with skinny jeans and boots.', '25% off', 'product_img/101ST1.jpg'),
('101ST2', 'Shirts', 'Jack & Jones', 'Printed Casual Shirt', 'S,M,L,XL', '15,18,8,12', '1499', 'Join the fashion forwards with this new printed shirt from Jack&Jones. Cut to precision, it fits seamlessly n looks exremelyy stylish as well. Team this with skinny jeans and loafers to finish this look.', '30% off', 'product_img/101ST02.jpg'),
('101ST3', 'Shirts', 'Jack & Jones', 'Printed Casual Shirt', 'S,M,L,XL', '0,6,13,7', '2499', 'Jack&Jones hooks you up with this latest trend this autumn. Make your style game strong with this printed white shirt. Team this with ripped jeans and loafers to finish this look.franchise has a new offering and so do we at Jack&Jones.This round neck printed t-shirt is coolness personified. Pair this with a denim jacket and ripped jeans and trainers.', '50% Off', 'product_img/101ST03.jpg'),
('101ST4', 'Shirts', 'Jack & Jones', 'SOLID CASUAL SHIRT', 'S,M,L,XL', '0,0,16,13', '2499', 'Denimize your wardrobe with this cool pair of denim in blackshirt from Jack&Jones. A staple for any mans wardrobe. Team it with blue denims and boots and finish the look.', '35% Off', 'product_img/104ST04.jpg'),
('101ST5', 'Shirts', 'Jack & Jones', 'Printed Casual Shirt', 'S,M,L,XL', '2,0,7,3', '2499', 'Jack&Jones brings you this uber cool printed shirt this season. Cut to fit effortlessly this shirt rounds your wardrobe essentials. Pair this with jeans and trainers to finish this look.', '45% Off', 'product_img/101ST05.jpg'),
('101ST6', 'Shirts', 'Jack & Jones', 'Printed Casual Shirt', 'S,M,L,XL', '19,1,8,2', '2499', 'Stock up this super stylish casual shirt from Jack&Jones. This brown shirt is perfect to take from board room to game room scene. Work this look with a pair of distresed denims and trainers.', '30% Off', 'product_img/101ST06.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `product_tbl`
--

CREATE TABLE IF NOT EXISTS `product_tbl` (
  `product_sku` varchar(25) NOT NULL,
  `product_cat` varchar(30) NOT NULL,
  `product_brand` varchar(50) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_size` varchar(30) NOT NULL,
  `product_qty` varchar(50) NOT NULL,
  `product_price` varchar(20) NOT NULL,
  `product_info` varchar(500) NOT NULL,
  `product_offer` varchar(30) NOT NULL,
  `product_img` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_tbl`
--

INSERT INTO `product_tbl` (`product_sku`, `product_cat`, `product_brand`, `product_name`, `product_size`, `product_qty`, `product_price`, `product_info`, `product_offer`, `product_img`) VALUES
('101', 'Tees & Polo', 'Jack & Jones', '101 Printed Casual Shirt', 'S,M,L', '7,11,5', '499', 'Amp your style with this ''Star War'' print shirt from Jack&Jones. This slim fit shirt is cut to fit to perfection. Style it with skinny jeans and boots.', '10% off', 'product_img/101.jpg'),
('102', 'Tees & Polo', 'Jack & Jones', '102 Printed Casual Shirt', 'S,M,L', '15,18,8', '449', 'Grab this ultimately stylish and trendy ''Star War'' from Jack&Jones. This printed t-shirt adds the right amount quirk to your personality.Team this with denims and boots.', '10% off', 'product_img/102.jpg'),
('103', 'Tees & Polo', 'Jack & Jones', '103 Printed Casual Shirt', 'S,M,L', '0,6,13', '699', 'Rejoice! you all Star War addicts, this one is for you. The cult franchise has a new offering and so do we at Jack&Jones.This round neck printed t-shirt is coolness personified. Pair this with a denim jacket and ripped jeans and trainers.', '', 'product_img/103.jpg'),
('104', 'Tees & Polo', 'Jack & Jones', '104 Printed Casual Shirt', 'S,M,L', '0,0,16', '999', 'Slay the fashion scene, with ''Star War'' printed t-shirt from Jack&Jones. This round neck printed t-shirt fits to perfection. Style this jogger and trainers to ace this look.', '15% Off', 'product_img/104.jpg'),
('105', 'Tees & Polo', 'Jack & Jones', '105 Printed Casual T-Shirt', 'S,M,L', '2,0,7', '849', 'Stock your favorite Star War t-shirt from Jack &Jones.This cool printed t-shirt super stylish. Team it with skinny jeans and trainers.', '12% Off', 'product_img/105.jpg'),
('106', 'Tees & Polo', 'Jack & Jones', '106 Solid Casual T-Shirt', 'S,M,L', '19,1,8', '799', 'Get set for atumn with this casual t-shirt from Jack and Jones.The navy t-shirt is, cut from the finest cotton to provide extreme comfort. Team this with a skinny jeans and boots to look super stylish.', '18% Off', 'product_img/106.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `product_tees&polo_tbl`
--

CREATE TABLE IF NOT EXISTS `product_tees&polo_tbl` (
  `product_sku` varchar(50) NOT NULL,
  `product_cat` varchar(50) NOT NULL,
  `product_brand` varchar(50) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `product_size` varchar(20) NOT NULL,
  `product_qty` varchar(20) NOT NULL,
  `product_price` varchar(20) NOT NULL,
  `product_info` varchar(500) NOT NULL,
  `product_offer` varchar(20) NOT NULL,
  `product_img` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_tees&polo_tbl`
--

INSERT INTO `product_tees&polo_tbl` (`product_sku`, `product_cat`, `product_brand`, `product_name`, `product_size`, `product_qty`, `product_price`, `product_info`, `product_offer`, `product_img`) VALUES
('101', 'Tees & Polo', 'Jack & Jones', '101 Printed Casual Shirt', 'S,M,L', '7,11,5', '499', 'Amp your style with this ''Star War'' print shirt from Jack&Jones. This slim fit shirt is cut to fit to perfection. Style it with skinny jeans and boots.', '10% off', 'product_img/101.jpg'),
('102', 'Tees & Polo', 'Jack & Jones', '102 Printed Casual Shirt', 'S,M,L', '15,18,8', '449', 'Grab this ultimately stylish and trendy ''Star War'' from Jack&Jones. This printed t-shirt adds the right amount quirk to your personality.Team this with denims and boots.', '10% off', 'product_img/102.jpg'),
('103', 'Tees & Polo', 'Jack & Jones', '103 Printed Casual Shirt', 'S,M,L', '0,6,13', '699', 'Rejoice! you all Star War addicts, this one is for you. The cult franchise has a new offering and so do we at Jack&Jones.This round neck printed t-shirt is coolness personified. Pair this with a denim jacket and ripped jeans and trainers.', '', 'product_img/103.jpg'),
('104', 'Tees & Polo', 'Jack & Jones', '104 Printed Casual Shirt', 'S,M,L', '0,0,16', '999', 'Slay the fashion scene, with ''Star War'' printed t-shirt from Jack&Jones. This round neck printed t-shirt fits to perfection. Style this jogger and trainers to ace this look.', '15% Off', 'product_img/104.jpg'),
('105', 'Tees & Polo', 'Jack & Jones', '105 Printed Casual T-Shirt', 'S,M,L', '2,0,7', '849', 'Stock your favorite Star War t-shirt from Jack &Jones.This cool printed t-shirt super stylish. Team it with skinny jeans and trainers.', '12% Off', 'product_img/105.jpg'),
('106', 'Tees & Polo', 'Jack & Jones', '106 Solid Casual T-Shirt', 'S,M,L', '19,1,8', '799', 'Get set for atumn with this casual t-shirt from Jack and Jones.The navy t-shirt is, cut from the finest cotton to provide extreme comfort. Team this with a skinny jeans and boots to look super stylish.', '18% Off', 'product_img/106.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `userAcc_tbl`
--

CREATE TABLE IF NOT EXISTS `userAcc_tbl` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(11) NOT NULL,
  `last_name` varchar(11) NOT NULL,
  `address` varchar(11) NOT NULL,
  `mobile` varchar(35) NOT NULL,
  `email_id` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `profile_img` varchar(50000) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userAcc_tbl`
--

INSERT INTO `userAcc_tbl` (`user_id`, `first_name`, `last_name`, `address`, `mobile`, `email_id`, `password`, `profile_img`) VALUES
(38, 'yogi', 'bare', 'surat', '1234567890', 'yogibare@gmail.com', 'yogibare123', 'ProfileImages/5865f57358e02.png'),
(39, 'image', 'parsing', 'xyz', '1234567890', 'image123@gmail.com', 'image123', 'ProfileImages/5865f64252f55.png'),
(40, 'puss', 'in boots', 'pussland', '9087898765', 'puss@ymail.com', 'puss123', 'ProfileImages/586df8b956680.png'),
(41, 'semein', 'contractor', 'valsad', '9874561230', 'semeinc@googlemail.c', 'password123', 'ProfileImages/589ec53ba6587.png'),
(42, 'hello', 'howareyou', 'surat', '9876543210', 'hello@gmail.com', 'hello123', 'ProfileImages/58b7baa4bd282.png'),
(43, 'semein', 'contractor', 'valsad', '9033579940', 'semeinc@gmail.com', 'password1', 'ProfileImages/propic.png'),
(44, 'test', 'demo', 'surat', '9876543210', 'test@gmail.com', 'test123', 'ProfileImages/58c26f1a86651.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `catagory_tbl`
--
ALTER TABLE `catagory_tbl`
  ADD PRIMARY KEY (`catagory_id`);

--
-- Indexes for table `product_jeans_tbl`
--
ALTER TABLE `product_jeans_tbl`
  ADD PRIMARY KEY (`product_sku`),
  ADD KEY `product_sku` (`product_sku`);

--
-- Indexes for table `product_shirts`
--
ALTER TABLE `product_shirts`
  ADD PRIMARY KEY (`product_sku`);

--
-- Indexes for table `product_tbl`
--
ALTER TABLE `product_tbl`
  ADD PRIMARY KEY (`product_sku`);

--
-- Indexes for table `product_tees&polo_tbl`
--
ALTER TABLE `product_tees&polo_tbl`
  ADD PRIMARY KEY (`product_sku`);

--
-- Indexes for table `userAcc_tbl`
--
ALTER TABLE `userAcc_tbl`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `userAcc_tbl`
--
ALTER TABLE `userAcc_tbl`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=45;--
-- Database: `Perfume`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `Id` int(3) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Contact` varchar(10) NOT NULL,
  `Password` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Id`, `Name`, `Email`, `Contact`, `Password`) VALUES
(1, 'vishal vaghasiya', 'vaghasiya907@gmail.com', '9725992972', '9fab6755cd2e8817d3e73b0978ca54a6'),
(2, 'Admin', 'admin@gmail.com', '9725992972', '25d55ad283aa400af464c76d713c07ad');

-- --------------------------------------------------------

--
-- Table structure for table `perfume_sale`
--

CREATE TABLE IF NOT EXISTS `perfume_sale` (
  `Perfume_Id` int(3) NOT NULL,
  `Perfume_Title` varchar(500) NOT NULL,
  `Perfume_Desc` varchar(1000) NOT NULL,
  `Perfume_Brand` varchar(50) NOT NULL,
  `Perfume_Ava` varchar(50) NOT NULL,
  `Perfume_Price` double NOT NULL,
  `Perfume_Term` varchar(500) NOT NULL,
  `Perfume_Upload_Date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Perfume_Image` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `perfume_sale`
--

INSERT INTO `perfume_sale` (`Perfume_Id`, `Perfume_Title`, `Perfume_Desc`, `Perfume_Brand`, `Perfume_Ava`, `Perfume_Price`, `Perfume_Term`, `Perfume_Upload_Date`, `Perfume_Image`) VALUES
(1, 'Whasapp', 'Coming Soon.', 'FERRARI', '50ML,100ML,150ML,200-ML', 2500, 'Coming Soon.', '2016-12-26 06:50:06', 'uploads/95701-1.jpg'),
(2, 'Facebook', 'Coming Soon.', 'Ralph Lauren', '50ML,100ML,150ML,200-ML', 3000, 'Coming Soon.', '2016-12-26 06:52:09', 'uploads/50760-2.jpg'),
(3, 'Twitter', 'Coming Soon.', 'Burberry', '50ML,100ML,150ML,200-ML', 6500, 'Coming Soon.', '2016-12-26 06:52:56', 'uploads/39475-3.jpg'),
(4, 'Google Plus', 'Coming Soon.', 'Giorgio Armani', '50ML,100ML,150ML,200-ML', 10000, 'Coming Soon.', '2016-12-26 06:53:32', 'uploads/13798-4.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `perfume_sale`
--
ALTER TABLE `perfume_sale`
  ADD PRIMARY KEY (`Perfume_Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Id` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `perfume_sale`
--
ALTER TABLE `perfume_sale`
  MODIFY `Perfume_Id` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;--
-- Database: `PostData`
--

-- --------------------------------------------------------

--
-- Table structure for table `Userdatabase`
--

CREATE TABLE IF NOT EXISTS `Userdatabase` (
  `Name` varchar(50) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Date` varchar(50) NOT NULL,
  `Profileimg` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Userdatabase`
--

INSERT INTO `Userdatabase` (`Name`, `Address`, `Date`, `Profileimg`) VALUES
('sam', '15/11/2017', 'sparrow', ''),
('semein', 'valsad', '07-03-17', ''),
('sam', 'surat', '03-12-16', 'ProfileImages/58be89bb06e34.png'),
('max', 'pain', '07-03-17', 'ProfileImages/58be8bd3b402f.png');
--
-- Database: `crime_tracker`
--

-- --------------------------------------------------------

--
-- Table structure for table `complaint`
--

CREATE TABLE IF NOT EXISTS `complaint` (
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `police_st_id` int(11) NOT NULL,
  `complaint_type` varchar(250) NOT NULL,
  `complaint_txt` varchar(1000) NOT NULL,
  `complaint_img` varchar(1000) NOT NULL,
  `complaint_video` varchar(1500) NOT NULL,
  `lattitude` varchar(1500) NOT NULL,
  `longitude` varchar(1500) NOT NULL,
  `complaint_status` varchar(500) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `complaint`
--

INSERT INTO `complaint` (`comp_id`, `user_id`, `police_st_id`, `complaint_type`, `complaint_txt`, `complaint_img`, `complaint_video`, `lattitude`, `longitude`, `complaint_status`) VALUES
(1, 0, 0, '', 'Nbdkkdkdfjbnkdfjbnkdfjbndfjkbfdjkbnkfjddbn', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `emergency_no.`
--

CREATE TABLE IF NOT EXISTS `emergency_no.` (
  `emrg_no_id` int(11) NOT NULL,
  `e_no_1` varchar(11) NOT NULL,
  `e_no_2` varchar(11) NOT NULL,
  `e_no_3` varchar(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `missing_person_details`
--

CREATE TABLE IF NOT EXISTS `missing_person_details` (
  `missing_p_id` int(11) NOT NULL,
  `m_p_name` varchar(200) NOT NULL,
  `m_p_img` varchar(1000) NOT NULL,
  `m_p_description` varchar(500) NOT NULL,
  `m_p_date` varchar(50) NOT NULL,
  `m_p_status` varchar(500) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `police_station`
--

CREATE TABLE IF NOT EXISTS `police_station` (
  `police_st_id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email_id` varchar(200) NOT NULL,
  `mobile_no` varchar(11) NOT NULL,
  `address` varchar(200) NOT NULL,
  `lettitude` varchar(500) NOT NULL,
  `longitude` varchar(500) NOT NULL,
  `password` varchar(500) NOT NULL,
  `status` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(200) NOT NULL,
  `address` varchar(500) NOT NULL,
  `mobile_no` varchar(11) NOT NULL,
  `email_id` varchar(200) NOT NULL,
  `pincode` varchar(7) NOT NULL,
  `aadharcard_no` varchar(200) NOT NULL,
  `voter_id` varchar(200) NOT NULL,
  `pancard_no` varchar(200) NOT NULL,
  `profile_image` varchar(1000) NOT NULL,
  `password` varchar(500) NOT NULL,
  `status` varchar(500) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `address`, `mobile_no`, `email_id`, `pincode`, `aadharcard_no`, `voter_id`, `pancard_no`, `profile_image`, `password`, `status`) VALUES
(1, 'bhumika', 'surat', '7894561523', 'bhumi@gmail.com', '7894561', '741258963', '456123789', '789456123', 'iambhumi', 'varsha123', 'single'),
(2, 'sonam', 'Bali ', '7894561230', 'sonam@gmail.com', '7894561', '852369741', '789456123', '', '', 'sonam123', 'single'),
(3, 'pooja', 'surat', '7894561230', 'pooja@qwe.com', '56231', '85236974', '7894561423', '', '', '123456', 'single');

-- --------------------------------------------------------

--
-- Table structure for table `wanted_person_details`
--

CREATE TABLE IF NOT EXISTS `wanted_person_details` (
  `wanted_p_id` int(11) NOT NULL,
  `w_p_name` varchar(200) NOT NULL,
  `w_p_img` varchar(1000) NOT NULL,
  `w_p_description` varchar(500) NOT NULL,
  `w_p_status` varchar(500) NOT NULL,
  `police_st_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `complaint`
--
ALTER TABLE `complaint`
  ADD PRIMARY KEY (`comp_id`);

--
-- Indexes for table `emergency_no.`
--
ALTER TABLE `emergency_no.`
  ADD PRIMARY KEY (`emrg_no_id`);

--
-- Indexes for table `missing_person_details`
--
ALTER TABLE `missing_person_details`
  ADD PRIMARY KEY (`missing_p_id`);

--
-- Indexes for table `police_station`
--
ALTER TABLE `police_station`
  ADD PRIMARY KEY (`police_st_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `wanted_person_details`
--
ALTER TABLE `wanted_person_details`
  ADD PRIMARY KEY (`wanted_p_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `complaint`
--
ALTER TABLE `complaint`
  MODIFY `comp_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `emergency_no.`
--
ALTER TABLE `emergency_no.`
  MODIFY `emrg_no_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `missing_person_details`
--
ALTER TABLE `missing_person_details`
  MODIFY `missing_p_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `police_station`
--
ALTER TABLE `police_station`
  MODIFY `police_st_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `wanted_person_details`
--
ALTER TABLE `wanted_person_details`
  MODIFY `wanted_p_id` int(11) NOT NULL AUTO_INCREMENT;--
-- Database: `db`
--

-- --------------------------------------------------------

--
-- Table structure for table `reg`
--

CREATE TABLE IF NOT EXISTS `reg` (
  `ID` int(11) NOT NULL,
  `UName` varchar(20) DEFAULT NULL,
  `Pass` varchar(20) DEFAULT NULL,
  `Email` varchar(20) DEFAULT NULL,
  `Mobile` varchar(10) DEFAULT NULL,
  `DOB` date DEFAULT NULL,
  `Hobby` varchar(30) DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL,
  `ImgURL` varchar(20) DEFAULT NULL,
  `City` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reg`
--

INSERT INTO `reg` (`ID`, `UName`, `Pass`, `Email`, `Mobile`, `DOB`, `Hobby`, `Gender`, `ImgURL`, `City`) VALUES
(1, 'Tejas', 'Tejas', 'danej.tejash0@gmail.', '1234567890', '0000-00-00', 'Cricket;Music', 'Male', 'img', 'Surat'),
(2, 'Tejas', 'Tejas', 'danej.tejash0@gmail.', '1234567890', '0000-00-00', 'Cricket;Music', 'Male', 'img', 'Surat'),
(3, 'Tejas', 'Tejas', 'danej.tejash0@gmail.', '1234567890', '0000-00-00', 'Cricket;Music', 'Male', 'img', 'Surat'),
(4, 'Tejas', 'Tejas', 'danej.tejash0@gmail.', '1234567890', '0000-00-00', 'Cricket;Music', 'Male', 'img', 'Surat'),
(5, 'Tejas', 'Tejas', 'danej.tejash0@gmail.', '1234567890', '1992-11-01', 'Cricket;Music', 'Male', 'img', 'Surat'),
(8, 'MeshPatel', 'meshpatel', 'meshPatel@gmail.com', '1234567890', '1994-01-26', 'Cricket;Music', 'Male', 'img', 'Surat'),
(9, 'Tejas', 'tejasdanej', 'tejasd@gmail.com', '1234567890', '1992-11-22', 'Cricket;Trable;Music', 'Male', 'img', 'Surat'),
(10, 'Jekil', 'jekil13', 'jekil@gmail.com', '7894561230', '1989-01-26', 'Cricket;Trable;Music', 'Male', 'img', ''),
(11, 'Jekil', 'jekil13', 'jekil@gmail.com', '7894561230', '1989-01-26', 'Cricket;Trable;Music', 'Male', 'img', ''),
(12, 'Jekil', 'jekil13', 'jekil@gmail.com', '7894561230', '1989-01-26', 'Cricket;Trable;Music', 'Male', 'img', ''),
(13, 'Jekil', 'jekil13', 'jekil@gmail.com', '7894561230', '1989-01-26', 'Cricket;Trable;Music', 'Male', 'img', ''),
(14, 'Ramallah', 'ramallah', 'radm@gamil.com', '8866544536', '1993-05-21', 'Cricket;Trable;Music', 'Male', 'img', ''),
(15, 'user test', 'usertest', 'user@user.com', '5647891231', '1991-01-20', 'Cricket;Trable;Music', 'Male', 'img', 'Delil'),
(16, 'Ahir', 'ahir123', 'ahir@ahir.com', '5467891243', '1973-01-29', 'Cricket;Trable;Music', 'Male', 'img', 'Valsad'),
(17, 'Ahir1', 'ahir123', 'ahir@ahir.com', '5467891243', '1973-01-29', 'Cricket;Trable;Music', 'Male', 'img', 'Valsad'),
(18, '', '', '', '', '1970-01-01', '', 'Male', 'img', ''),
(19, '', '', '', '', '2047-12-23', '', '', 'img', 'Surat');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `reg`
--
ALTER TABLE `reg`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `reg`
--
ALTER TABLE `reg`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;--
-- Database: `db_crime_track`
--

-- --------------------------------------------------------

--
-- Table structure for table `Add_Tiffin_details`
--

CREATE TABLE IF NOT EXISTS `Add_Tiffin_details` (
  `tiffin_id` int(11) NOT NULL,
  `service_provider_id` int(11) NOT NULL,
  `tiffin_name` varchar(100) NOT NULL,
  `number_of_item` int(11) NOT NULL,
  `description` varchar(500) NOT NULL,
  `price` float NOT NULL,
  `status` varchar(500) NOT NULL,
  `tiffin_image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Assign_order`
--

CREATE TABLE IF NOT EXISTS `Assign_order` (
  `assign_id` int(11) NOT NULL,
  `assign_delivery_boy_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `assign_date` date NOT NULL,
  `assign_time` time NOT NULL,
  `status` varchar(500) NOT NULL,
  `tocken_number` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Complaint`
--

CREATE TABLE IF NOT EXISTS `Complaint` (
  `comp_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `ps_id` int(11) NOT NULL,
  `police_id` int(11) NOT NULL,
  `complaint_type` varchar(50) NOT NULL,
  `description` varchar(100) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `video_url` varchar(100) NOT NULL,
  `audio_url` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Complaint`
--

INSERT INTO `Complaint` (`comp_id`, `uid`, `ps_id`, `police_id`, `complaint_type`, `description`, `latitude`, `longitude`, `date`, `time`, `video_url`, `audio_url`, `status`) VALUES
(1, 4, 2, 3, 'Robery', 'this is the robbery case', 19.204516, 72.85201, '2016-04-18', '11:42:24', 'no', 'no', 'assign'),
(2, 4, 6, 0, 'Corruption', 'this is the corruption case', 19.040208, 72.85085, '2016-04-18', '11:54:03', 'no', 'no', 'closed'),
(5, 4, 2, 0, 'Robery', 'this is the robbery case', 19.098821, 72.832072, '2016-04-18', '11:42:24', '', '', 'closed'),
(6, 4, 2, 0, 'Robery', 'this is the robbery case', 19.060692, 72.83625, '2016-04-18', '11:42:24', '', '', 'closed'),
(7, 4, 2, 4, 'Robery', 'this is the robbery case', 19.0176147, 72.8561644, '2016-04-18', '11:42:24', 'no', 'no', 'Accepted'),
(8, 4, 2, 0, 'Corruption', 'dfgg', 19.113645, 72.869734, '2016-05-14', '14:02:32', '', '', 'view'),
(9, 4, 2, 3, 'Forgery', 'sdfsdsfd', 19.237188, 72.844136, '2016-05-16', '17:25:33', 'no', 'no', 'Accepted'),
(10, 4, 2, 0, 'Corruption', 'this is the case of corruption', 19.180237, 72.855415, '2016-05-14', '14:02:32', '', '', 'closed'),
(11, 4, 6, 0, 'Corruption', 'gfhfghfghfghfgh', 19.0176147, 72.8561644, '2016-06-18', '19:25:21', 'no', 'no', 'view'),
(12, 4, 6, 0, 'Forgery', 'this is the forgery case', 19.0176147, 72.8561644, '2016-07-03', '02:40:48', 'no', 'no', 'view'),
(13, 4, 6, 0, 'Corruption', 'hi this is crime', 19.0176147, 72.8561644, '2016-07-03', '05:08:24', 'no', 'no', 'process'),
(14, 5, 6, 0, 'Forgery', 'this is the status check', 19.0176147, 72.8561644, '2016-07-03', '17:08:34', 'no', 'no', 'done'),
(15, 4, 6, 0, 'Forgery', 'this is testing video uploading', 19.0176147, 72.8561644, '2016-07-04', '04:07:11', 'no', 'no', 'sent'),
(16, 4, 6, 0, 'Forgery', 'dshfkjsdf', 19.0176147, 72.8561644, '2016-07-04', '04:15:54', 'no', 'no', 'view'),
(17, 4, 6, 0, 'Forgery', 'dfdfgdg gig', 19.0176147, 72.8561644, '2016-07-04', '04:24:43', 'no', 'no', 'view'),
(18, 4, 6, 0, 'Forgery', 'foreforefore', 19.0176147, 72.8561644, '2016-07-04', '05:10:57', 'http://localhost/crime/uploads/vid6658.mp4', 'http://localhost/crime/uploads/rec5551.m4a', 'closed'),
(19, 4, 6, 0, 'Corruption', 'etfetet', 19.0176147, 72.8561644, '2016-09-01', '12:16:29', 'no', 'no', 'sent');

-- --------------------------------------------------------

--
-- Table structure for table `Dilevery_Boy_Table`
--

CREATE TABLE IF NOT EXISTS `Dilevery_Boy_Table` (
  `dilevery_boy_id` int(11) NOT NULL,
  `name` int(11) NOT NULL,
  `mobail_no` int(10) NOT NULL,
  `service_provider_id` int(11) NOT NULL,
  `status` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Discount_details`
--

CREATE TABLE IF NOT EXISTS `Discount_details` (
  `discount_id` int(11) NOT NULL,
  `service_provider_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `percentage_discount` int(11) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Order_details`
--

CREATE TABLE IF NOT EXISTS `Order_details` (
  `order_id` int(11) NOT NULL,
  `service_provider_id` int(11) NOT NULL,
  `tiffin_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `status` varchar(500) NOT NULL,
  `description` varchar(500) NOT NULL,
  `tocken_no` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Package_details`
--

CREATE TABLE IF NOT EXISTS `Package_details` (
  `package_id` int(11) NOT NULL,
  `service_ provider_id` int(11) NOT NULL,
  `tiffin_id` int(11) NOT NULL,
  `package_price` int(11) NOT NULL,
  `number_of_tiffin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Service_provider_registraion`
--

CREATE TABLE IF NOT EXISTS `Service_provider_registraion` (
  `service_provider_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` varchar(500) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `mobail_no` int(11) NOT NULL,
  `status` varchar(100) NOT NULL,
  `lat` varchar(100) NOT NULL,
  `long` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `User_registration`
--

CREATE TABLE IF NOT EXISTS `User_registration` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `mobail_no` int(11) NOT NULL,
  `status` varchar(500) NOT NULL,
  `lat` varchar(100) NOT NULL,
  `long` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `User_registration`
--

INSERT INTO `User_registration` (`user_id`, `user_name`, `email`, `password`, `mobail_no`, `status`, `lat`, `long`) VALUES
(1, 'Tops', 'Tops@gmail.com', 'helloh', 982, '', '', ''),
(2, 'Topstech', 'Topstech@gmail.com', 'surats', 987, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `User_review`
--

CREATE TABLE IF NOT EXISTS `User_review` (
  `review_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `description` varchar(500) NOT NULL,
  `rating` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `complaint_img`
--

CREATE TABLE IF NOT EXISTS `complaint_img` (
  `ci_id` int(11) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `image_url` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `complaint_img`
--

INSERT INTO `complaint_img` (`ci_id`, `comp_id`, `image_url`) VALUES
(1, 1, 'http://localhost/crime/uploads/C8043.jpg'),
(2, 1, 'http://localhost/crime/uploads/C8358.jpg'),
(3, 1, 'http://localhost/crime/uploads/C9413.jpg'),
(4, 1, 'http://localhost/crime/uploads/C4476.jpg'),
(5, 2, 'http://localhost/crime/uploads/C1970.jpg'),
(6, 2, 'http://localhost/crime/uploads/C2411.jpg'),
(7, 2, 'http://localhost/crime/uploads/C9743.jpg'),
(8, 2, 'http://localhost/crime/uploads/C5996.jpg'),
(9, 8, 'http://localhost/crime/uploads/C5191.jpg'),
(10, 8, 'http://localhost/crime/uploads/C1004.jpg'),
(11, 8, 'http://localhost/crime/uploads/C7435.jpg'),
(12, 8, 'http://localhost/crime/uploads/C1210.jpg'),
(13, 9, 'http://localhost/crime/uploads/C2281.jpg'),
(14, 9, 'http://localhost/crime/uploads/C2726.jpg'),
(15, 9, 'http://localhost/crime/uploads/C6427.jpg'),
(16, 9, 'http://localhost/crime/uploads/C3550.jpg'),
(17, 11, 'http://localhost/crime/uploads/C3229.jpg'),
(18, 11, 'http://localhost/crime/uploads/C9241.jpg'),
(19, 12, 'http://localhost/crime/uploads/C7291.jpg'),
(20, 12, 'http://localhost/crime/uploads/C8208.jpg'),
(21, 12, 'http://localhost/crime/uploads/C9784.jpg'),
(22, 12, 'http://localhost/crime/uploads/C3253.jpg'),
(23, 13, 'http://localhost/crime/uploads/C6522.jpg'),
(24, 13, 'http://localhost/crime/uploads/C5943.jpg'),
(25, 13, 'http://localhost/crime/uploads/C2316.jpg'),
(26, 13, 'http://localhost/crime/uploads/C4977.jpg'),
(27, 14, 'http://localhost/crime/uploads/C4037.jpg'),
(28, 14, 'http://localhost/crime/uploads/C4233.jpg'),
(29, 14, 'http://localhost/crime/uploads/C4804.jpg'),
(30, 14, 'http://localhost/crime/uploads/C3469.jpg'),
(31, 15, 'http://localhost/crime/uploads/C6018.jpg'),
(32, 15, 'http://localhost/crime/uploads/C6352.jpg'),
(33, 15, 'http://localhost/crime/uploads/C5995.jpg'),
(34, 16, 'http://localhost/crime/uploads/C9851.jpg'),
(35, 16, 'http://localhost/crime/uploads/C1789.jpg'),
(36, 17, 'http://localhost/crime/uploads/C4192.jpg'),
(37, 17, 'http://localhost/crime/uploads/C7623.jpg'),
(38, 17, 'http://localhost/crime/uploads/C5550.jpg'),
(39, 18, 'http://localhost/crime/uploads/C5759.jpg'),
(40, 18, 'http://localhost/crime/uploads/C5085.jpg'),
(41, 18, 'http://localhost/crime/uploads/C2755.jpg'),
(42, 19, 'http://localhost/crime/uploads/C3489.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `crime_type`
--

CREATE TABLE IF NOT EXISTS `crime_type` (
  `Crimetype_id` int(11) NOT NULL,
  `Crimetype_name` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `crime_type`
--

INSERT INTO `crime_type` (`Crimetype_id`, `Crimetype_name`) VALUES
(1, 'Robery'),
(2, 'Forgery'),
(3, 'Corruption'),
(4, 'Solicitation'),
(5, 'Arson'),
(6, 'Burglary');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `feed_id` int(11) NOT NULL,
  `Give_rate` float NOT NULL,
  `Feedback_detail` varchar(100) NOT NULL,
  `uid` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`feed_id`, `Give_rate`, `Feedback_detail`, `uid`) VALUES
(1, 2.5, 'good application for surat people', 4),
(2, 3.5, 'hi very good application man\n', 4),
(3, 5, 'Enter Feedback', 4),
(4, 5, 'Enter Feedback hiasdak', 4),
(5, 5, 'asfkjhds', 4),
(6, 5, 'asdghjgasdjhgasd', 4),
(7, 3, 'sdfhjkhsdf', 4),
(8, 0, 'sdfsdfsdfsdfsdfsdfsdfsdfsdfsdf', 4),
(9, 4.5, 'Enter Feedback', 4);

-- --------------------------------------------------------

--
-- Table structure for table `missingFoundLocation`
--

CREATE TABLE IF NOT EXISTS `missingFoundLocation` (
  `mfl_id` int(11) NOT NULL,
  `Mperson_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `ps_id` int(11) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `missingFoundLocation`
--

INSERT INTO `missingFoundLocation` (`mfl_id`, `Mperson_id`, `uid`, `ps_id`, `latitude`, `longitude`, `date`, `time`) VALUES
(1, 6, 4, 2, 19.0176147, 72.8561644, '2016-05-11', '19:31:29'),
(3, 10, 4, 2, 19.0176147, 72.8561644, '2016-05-11', '19:36:30'),
(4, 11, 4, 2, 19.0176147, 72.8561644, '2016-05-14', '14:05:38'),
(5, 5, 4, 2, 19.0176147, 72.8561644, '2016-05-16', '17:28:58'),
(6, 11, 4, 6, 19.0176147, 72.8561644, '2016-05-16', '17:29:57'),
(7, 8, 4, 6, 19.0176147, 72.8561644, '2016-06-17', '11:09:19');

-- --------------------------------------------------------

--
-- Table structure for table `missing_person`
--

CREATE TABLE IF NOT EXISTS `missing_person` (
  `Mperson_id` int(11) NOT NULL,
  `Mperson_name` varchar(50) NOT NULL,
  `Mperson_contact` bigint(10) NOT NULL,
  `Mperson_desc` varchar(100) NOT NULL,
  `Age` int(11) NOT NULL,
  `Missing_date` date NOT NULL,
  `Mperson_photo` varchar(100) NOT NULL,
  `Mperosn_status` int(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `missing_person`
--

INSERT INTO `missing_person` (`Mperson_id`, `Mperson_name`, `Mperson_contact`, `Mperson_desc`, `Age`, `Missing_date`, `Mperson_photo`, `Mperosn_status`) VALUES
(5, 'Jignesh', 8866447788, 'white skin in bouncy hair', 25, '2016-05-01', 'http://localhost/crime/uploads/W3881.jpg', 0),
(6, 'Kishan Godhani', 9537830816, 'Off skin white body', 25, '2018-06-26', 'http://localhost/crime/uploads/W5798.jpg', 1),
(8, 'Honey singh', 7897898787, 'black color highted', 50, '2016-02-28', 'http://localhost/crime/uploads/W2645.jpg', 1),
(10, 'angel', 8989898898, 'nice cute baby', 15, '2016-08-04', 'http://localhost/crime/uploads/W8334.jpg', 1),
(11, 'karan', 7676676767, 'saghfh', 22, '2016-07-07', 'http://localhost/crime/uploads/W9559.jpg', 1),
(12, 'denish', 783495738, 'sadfhkjsadhfk', 45, '0000-00-00', 'http://localhost/crime/uploads/W6342.jpg', 1),
(13, 'jigs', 576567567, 'sdfjhsgdjfh', 65, '2019-08-21', 'http://localhost/crime/uploads/W2649.jpg', 1),
(14, 'Hetal', 7908877799, 'white color skin ', 40, '2016-01-26', 'http://localhost/crime/uploads/W9422.jpg', 0),
(15, 'abc', 9989989999, 'abc', 21, '2016-04-29', 'http://localhost/crime/uploads/W8152.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `policeman_info`
--

CREATE TABLE IF NOT EXISTS `policeman_info` (
  `police_id` int(11) NOT NULL,
  `ps_id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `post` varchar(50) NOT NULL,
  `contact` bigint(10) NOT NULL,
  `photo_url` varchar(100) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `policeman_info`
--

INSERT INTO `policeman_info` (`police_id`, `ps_id`, `name`, `post`, `contact`, `photo_url`, `status`) VALUES
(1, 2, 'Amit Kumar', 'Constable', 9997788999, 'http://localhost/crime/uploads/W9035.jpg', 0),
(3, 2, 'Vikram Rathod', 'Assistant Sub Inspector', 5678456757, 'http://localhost/crime/uploads/police5411.jpg', 0),
(4, 2, 'Harsh Patel', 'Assistant Sub Inspector', 9898978777, 'http://localhost/crime/uploads/police9000.jpg', 1),
(5, 6, 'Sadhu Yadav', 'PSI', 8989898989, 'ddfhjdfhj', 0),
(6, 6, 'Kiran Patel', 'Sub Inspector', 8989898989, 'djhfsjkdfhsd', 0);

-- --------------------------------------------------------

--
-- Table structure for table `policestn_reg`
--

CREATE TABLE IF NOT EXISTS `policestn_reg` (
  `ps_id` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Contact` bigint(10) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Latitude` double NOT NULL,
  `Longitude` double NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `policestn_reg`
--

INSERT INTO `policestn_reg` (`ps_id`, `Name`, `Address`, `Contact`, `Username`, `Password`, `Latitude`, `Longitude`, `status`) VALUES
(2, 'kapodra police station', 'kapodra,surat', 2256487, 'admin', '123456', 21.2187655, 72.8745776, 0),
(3, 'Kamrej Police Station', 'kamrej.surat', 2265978, 'kamrej', 'kamrej', 21.2675544, 72.9608575, 0),
(4, 'Citylight Police Station', 'citylight,surat', 22652464, 'citylight', 'citylight', 21.166718, 72.7955185, 0),
(5, 'Pandesara Police Station', 'pandesara,surat', 22894577, 'pandesara', 'pandesara', 21.1502576, 72.82496069999999, 0),
(6, 'Udhna Police Station', 'udhna,surat', 22587877, 'udhna', 'udhna12', 21.1431152, 72.8431097, 0),
(7, 'Sarthana Police Station', 'sarthana,surat', 987897887, 'sarthana', 'sarthana', 21.2305574, 72.901545, 0);

-- --------------------------------------------------------

--
-- Table structure for table `suggestion`
--

CREATE TABLE IF NOT EXISTS `suggestion` (
  `sugg_id` int(11) NOT NULL,
  `title` varchar(30) NOT NULL,
  `suggestion` varchar(100) NOT NULL,
  `ps_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `suggestion`
--

INSERT INTO `suggestion` (`sugg_id`, `title`, `suggestion`, `ps_id`, `uid`) VALUES
(1, 'hi this is title', 'sdfdfsfdsdfhsdjkfh', 3, 4),
(2, 'This is the suggestion ', 'this is suggestion demo descriptsiutrdsfjkhjkdfgdfg', 2, 4),
(3, 'drtyrtyrtyrtyrtyrtyrty', 'sdfdfgdffgdfnyrtyurtmumhgncfnfvbnvbnvbnvbnvbnvbnvbnvcbnvcbnvbn', 2, 4);

-- --------------------------------------------------------

--
-- Table structure for table `superuser`
--

CREATE TABLE IF NOT EXISTS `superuser` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `superuser`
--

INSERT INTO `superuser` (`id`, `name`, `username`, `password`) VALUES
(1, 'Super User', 'super', 'super456');

-- --------------------------------------------------------

--
-- Table structure for table `unsatisfied_reason`
--

CREATE TABLE IF NOT EXISTS `unsatisfied_reason` (
  `reason_id` int(11) NOT NULL,
  `reason` varchar(200) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `unsatisfied_reason`
--

INSERT INTO `unsatisfied_reason` (`reason_id`, `reason`, `comp_id`, `uid`) VALUES
(1, 'i am not satisfied demo testing', 5, 4),
(2, 'my compalint is not complete yet', 2, 4),
(3, 'jignesh testing applyed', 5, 4),
(4, 'dfgdfgdfgdfgdfgdfgdg', 2, 4),
(5, 'fafsfssfssaf ', 18, 4);

-- --------------------------------------------------------

--
-- Table structure for table `userinfo`
--

CREATE TABLE IF NOT EXISTS `userinfo` (
  `uid` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Surname` varchar(50) NOT NULL,
  `Address1` varchar(50) NOT NULL,
  `Address2` varchar(50) NOT NULL,
  `Mobile` bigint(10) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Profilephoto` varchar(100) NOT NULL,
  `Aadharno` bigint(12) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userinfo`
--

INSERT INTO `userinfo` (`uid`, `Name`, `Surname`, `Address1`, `Address2`, `Mobile`, `Email`, `Username`, `Password`, `Profilephoto`, `Aadharno`, `status`) VALUES
(4, 'Jignesh', 'Maradiya', '103 Sayhog soc-1', 'Punagam', 9274743993, 'maradiyajignesh@gmail.com', 'user', 'user123', 'http://localhost/crime/uploads/PRO9225.jpg', 444433332222, 0),
(5, 'Cretan', 'margarita', '103 Ashton society', 'Surat', 9924752792, 'maradiyajignesh@yahoo.com', 'Cretan', 'chetan123', '', 222233334444, 0),
(6, 'Chintan', 'Maisuriya', 'Bhatar road', 'surat', 7359189897, 'abc@gmail.com', 'user', 'user123', '', 789999541232, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wantedFoundLocation`
--

CREATE TABLE IF NOT EXISTS `wantedFoundLocation` (
  `wfl_id` int(11) NOT NULL,
  `Wperson_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `ps_id` int(11) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wantedFoundLocation`
--

INSERT INTO `wantedFoundLocation` (`wfl_id`, `Wperson_id`, `uid`, `ps_id`, `latitude`, `longitude`, `date`, `time`) VALUES
(2, 6, 4, 2, 19.0176147, 72.8561644, '2016-05-18', '12:18:57');

-- --------------------------------------------------------

--
-- Table structure for table `wanted_person`
--

CREATE TABLE IF NOT EXISTS `wanted_person` (
  `Wperson_id` int(11) NOT NULL,
  `Wperson_name` varchar(50) NOT NULL,
  `Crime_type` varchar(50) NOT NULL,
  `Wperson_desc` varchar(100) NOT NULL,
  `Wperson_photo` varchar(100) NOT NULL,
  `Wperson_status` int(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wanted_person`
--

INSERT INTO `wanted_person` (`Wperson_id`, `Wperson_name`, `Crime_type`, `Wperson_desc`, `Wperson_photo`, `Wperson_status`) VALUES
(6, 'Nikunj', 'Forgery', 'most wanted dagabaaj', 'http://localhost/crime/uploads/W1836.jpg', 1),
(7, 'Lukkaa saheb', 'Burglary', 'Most wanted people', 'http://localhost/crime/uploads/W6046.jpg', 0),
(8, 'kulan devi', 'Forgery', 'sabse badi chor', 'http://localhost/crime/uploads/W7464.jpg', 0),
(9, 'chetan', 'Forgery', 'most corrupted person', 'http://localhost/crime/uploads/W2546.jpg', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Add_Tiffin_details`
--
ALTER TABLE `Add_Tiffin_details`
  ADD UNIQUE KEY `service_provider_id` (`service_provider_id`);

--
-- Indexes for table `Assign_order`
--
ALTER TABLE `Assign_order`
  ADD PRIMARY KEY (`assign_id`),
  ADD UNIQUE KEY `assign_delivery_boy_id` (`assign_delivery_boy_id`,`order_id`);

--
-- Indexes for table `Complaint`
--
ALTER TABLE `Complaint`
  ADD PRIMARY KEY (`comp_id`);

--
-- Indexes for table `Dilevery_Boy_Table`
--
ALTER TABLE `Dilevery_Boy_Table`
  ADD UNIQUE KEY `service_provider_id` (`service_provider_id`);

--
-- Indexes for table `Discount_details`
--
ALTER TABLE `Discount_details`
  ADD UNIQUE KEY `sp_id` (`service_provider_id`);

--
-- Indexes for table `Order_details`
--
ALTER TABLE `Order_details`
  ADD PRIMARY KEY (`order_id`),
  ADD UNIQUE KEY `service_provider_id` (`service_provider_id`,`tiffin_id`);

--
-- Indexes for table `Service_provider_registraion`
--
ALTER TABLE `Service_provider_registraion`
  ADD PRIMARY KEY (`service_provider_id`);

--
-- Indexes for table `User_registration`
--
ALTER TABLE `User_registration`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `complaint_img`
--
ALTER TABLE `complaint_img`
  ADD PRIMARY KEY (`ci_id`);

--
-- Indexes for table `crime_type`
--
ALTER TABLE `crime_type`
  ADD PRIMARY KEY (`Crimetype_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feed_id`);

--
-- Indexes for table `missingFoundLocation`
--
ALTER TABLE `missingFoundLocation`
  ADD PRIMARY KEY (`mfl_id`);

--
-- Indexes for table `missing_person`
--
ALTER TABLE `missing_person`
  ADD PRIMARY KEY (`Mperson_id`);

--
-- Indexes for table `policeman_info`
--
ALTER TABLE `policeman_info`
  ADD PRIMARY KEY (`police_id`);

--
-- Indexes for table `policestn_reg`
--
ALTER TABLE `policestn_reg`
  ADD PRIMARY KEY (`ps_id`);

--
-- Indexes for table `suggestion`
--
ALTER TABLE `suggestion`
  ADD PRIMARY KEY (`sugg_id`);

--
-- Indexes for table `superuser`
--
ALTER TABLE `superuser`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unsatisfied_reason`
--
ALTER TABLE `unsatisfied_reason`
  ADD PRIMARY KEY (`reason_id`);

--
-- Indexes for table `userinfo`
--
ALTER TABLE `userinfo`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `wantedFoundLocation`
--
ALTER TABLE `wantedFoundLocation`
  ADD PRIMARY KEY (`wfl_id`);

--
-- Indexes for table `wanted_person`
--
ALTER TABLE `wanted_person`
  ADD PRIMARY KEY (`Wperson_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Assign_order`
--
ALTER TABLE `Assign_order`
  MODIFY `assign_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Complaint`
--
ALTER TABLE `Complaint`
  MODIFY `comp_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `Order_details`
--
ALTER TABLE `Order_details`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Service_provider_registraion`
--
ALTER TABLE `Service_provider_registraion`
  MODIFY `service_provider_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `User_registration`
--
ALTER TABLE `User_registration`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `complaint_img`
--
ALTER TABLE `complaint_img`
  MODIFY `ci_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=43;
--
-- AUTO_INCREMENT for table `crime_type`
--
ALTER TABLE `crime_type`
  MODIFY `Crimetype_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feed_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `missingFoundLocation`
--
ALTER TABLE `missingFoundLocation`
  MODIFY `mfl_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `missing_person`
--
ALTER TABLE `missing_person`
  MODIFY `Mperson_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `policeman_info`
--
ALTER TABLE `policeman_info`
  MODIFY `police_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `policestn_reg`
--
ALTER TABLE `policestn_reg`
  MODIFY `ps_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `suggestion`
--
ALTER TABLE `suggestion`
  MODIFY `sugg_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `superuser`
--
ALTER TABLE `superuser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `unsatisfied_reason`
--
ALTER TABLE `unsatisfied_reason`
  MODIFY `reason_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `userinfo`
--
ALTER TABLE `userinfo`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `wantedFoundLocation`
--
ALTER TABLE `wantedFoundLocation`
  MODIFY `wfl_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `wanted_person`
--
ALTER TABLE `wanted_person`
  MODIFY `Wperson_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;--
-- Database: `demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `category_master`
--

CREATE TABLE IF NOT EXISTS `category_master` (
  `ID` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category_master`
--

INSERT INTO `category_master` (`ID`, `name`, `image`) VALUES
(10, 'ghjhg', 'images/594b603e5f943.png'),
(11, 'moin', 'images/594b609277fbd.png'),
(12, 'moin', 'images/594b60d74da46.png'),
(13, 'gg', 'images/594b64d66c8a8.png'),
(14, 'h', 'images/594b65599d016.png'),
(15, 'ggh', 'images/594b66546586c.png'),
(16, 'hhh', 'images/594b71fce77bd.png'),
(17, 'mm', 'images/594b729a837bc.png'),
(18, 'hardik', 'images/594b733b742dc.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category_master`
--
ALTER TABLE `category_master`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category_master`
--
ALTER TABLE `category_master`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;--
-- Database: `employee_details`
--

-- --------------------------------------------------------

--
-- Table structure for table `table`
--

CREATE TABLE IF NOT EXISTS `table` (
  `emp_id` int(100) NOT NULL,
  `emp_name` varchar(100) NOT NULL,
  `emp_city` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Database: `iWitness`
--

-- --------------------------------------------------------

--
-- Table structure for table `Complaint`
--

CREATE TABLE IF NOT EXISTS `Complaint` (
  `cID` int(11) NOT NULL,
  `UID` int(11) NOT NULL,
  `psID` int(11) NOT NULL,
  `poID` int(11) NOT NULL,
  `ctID` int(11) NOT NULL,
  `cDetails` varchar(150) NOT NULL,
  `locationAddress` varchar(100) NOT NULL,
  `latitude` varchar(50) NOT NULL,
  `longitude` varchar(50) NOT NULL,
  `cDate` date NOT NULL,
  `cTime` time NOT NULL,
  `cIMG_URLs` varchar(500) NOT NULL,
  `cStatus` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Complaint`
--

INSERT INTO `Complaint` (`cID`, `UID`, `psID`, `poID`, `ctID`, `cDetails`, `locationAddress`, `latitude`, `longitude`, `cDate`, `cTime`, `cIMG_URLs`, `cStatus`) VALUES
(1, 1, 9, 0, 5, 'I witnessed the bribery case nearby my society. Rs. 1 lac has been demanded from the bribe side.', 'B/1, Sewari Wadala Road, Mumbai, Maharashtra, India - 400019', '19.01761469999999931701', '72.85616439999999727206', '2016-10-08', '11:05:11', 'http://localhost/iWitness_WS/uploads/C4313.jpg,http://localhost/iWitness_WS/uploads/C4001.jpg,http://localhost/iWitness_WS/uploads/C7114.jpg,http://localhost/iWitness_WS/uploads/C7691.jpg', 'sent'),
(2, 1, 9, 0, 9, 'Two days ago, I became the victim of the cybercrime as Rs. 5000 withdrawn from my SBI account as I replied all my Debit Card information to the mail s', 'B/1, Sewari Wadala Road, Mumbai, Maharashtra, India - 400019', '19.01761469999999931701', '72.85616439999999727206', '2016-10-08', '11:11:00', 'http://localhost/iWitness_WS/uploads/C4418.jpg,http://localhost/iWitness_WS/uploads/C6634.jpg', 'sent'),
(3, 2, 9, 0, 15, 'There are some neighbor in our society who continuously disturbing us by doing miscellaneous activities.     ', 'B/1, Sewari Wadala Road, Mumbai, Maharashtra, India - 400019', '19.01761469999999931701', '72.85616439999999727206', '2016-10-08', '11:17:05', 'http://localhost/iWitness_WS/uploads/C3279.jpg,http://localhost/iWitness_WS/uploads/C7458.jpg', 'sent'),
(4, 2, 9, 9, 20, 'I witnessed an accident made by the person who is drunk and the opposite party is badly injured.', 'B/1, Sewari Wadala Road, Mumbai, Maharashtra, India - 400019', '19.01761469999999931701', '72.85616439999999727206', '2016-10-08', '11:22:41', 'http://localhost/iWitness_WS/uploads/C1113.jpg,http://localhost/iWitness_WS/uploads/C5584.jpg,http://localhost/iWitness_WS/uploads/C2147.jpg', 'sent'),
(5, 1, 9, 9, 46, 'My cell-phone is stolen a hour ago', 'B/1, Sewari Wadala Road, Mumbai, Maharashtra, India - 400019', '19.01761469999999931701', '72.85616439999999727206', '2016-10-08', '11:29:25', 'http://localhost/iWitness_WS/uploads/C8888.jpg,http://localhost/iWitness_WS/uploads/C5875.jpg', 'sent');

-- --------------------------------------------------------

--
-- Table structure for table `Feedbacks`
--

CREATE TABLE IF NOT EXISTS `Feedbacks` (
  `fbID` int(11) NOT NULL,
  `UID` int(11) NOT NULL,
  `feedBacks` varchar(50) NOT NULL,
  `givenRates` float NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Feedbacks`
--

INSERT INTO `Feedbacks` (`fbID`, `UID`, `feedBacks`, `givenRates`) VALUES
(1, 1, 'Excellent service provided. ', 5),
(2, 2, 'Good service', 4.5),
(3, 1, 'Nice work done by police department', 4.5);

-- --------------------------------------------------------

--
-- Table structure for table `Suggestions`
--

CREATE TABLE IF NOT EXISTS `Suggestions` (
  `sugID` int(11) NOT NULL,
  `UID` int(11) NOT NULL,
  `psID` int(11) NOT NULL,
  `sugSubject` varchar(50) NOT NULL,
  `sugDetail` varchar(80) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Suggestions`
--

INSERT INTO `Suggestions` (`sugID`, `UID`, `psID`, `sugSubject`, `sugDetail`) VALUES
(1, 1, 1, 'Subject to work upgradation', 'I complained for my lost cellphone about tow weeks ago. Still there is no progre'),
(2, 2, 3, 'About service', 'Please improve your service'),
(3, 1, 11, 'About traffic management', 'I stuck in the traffic since last half an hour. But there is no traffic police t');

-- --------------------------------------------------------

--
-- Table structure for table `crimeTypes`
--

CREATE TABLE IF NOT EXISTS `crimeTypes` (
  `ctID` int(11) NOT NULL,
  `ctName` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `crimeTypes`
--

INSERT INTO `crimeTypes` (`ctID`, `ctName`) VALUES
(1, 'Arson'),
(2, 'Assault'),
(3, 'Aggravated Assault/Battery'),
(4, 'Attempt'),
(5, 'Bribery'),
(6, 'Child Abandonment'),
(7, 'Child Abuse'),
(8, 'Child Pornography'),
(9, 'Computer Crime/Cyber Crime'),
(10, 'Conspiracy'),
(11, 'Credit / Debit Card Fraud'),
(12, 'Cyber Bullying'),
(13, 'Criminal Contempt of Court'),
(14, 'Disorderly Conduct'),
(15, 'Disturbing the Peace'),
(16, 'Domestic Violence'),
(17, 'Drug Manufacturing and Cultivation'),
(18, 'Drug Trafficking/Distribution'),
(19, 'Drug Possession'),
(20, 'Drunk Driving/DUI/DWI'),
(21, 'Embezzlement'),
(22, 'Extortion'),
(23, 'Forgery'),
(24, 'Fraud'),
(25, 'Harassment'),
(26, 'Hate Crime'),
(27, 'Homicide'),
(28, 'Indecent Exposure'),
(29, 'Identity Theft'),
(30, 'Insurance Fraud'),
(31, 'Kidnapping'),
(32, 'Manslaughter: Involuntary/Voluntary'),
(33, 'Money Laundering'),
(34, 'Murder'),
(35, 'Perjury'),
(36, 'Probation Violation'),
(37, 'Prostitution'),
(38, 'Public Intoxication'),
(39, 'Racketeering'),
(40, 'Rape'),
(41, 'Robbery'),
(42, 'Sexual Assault'),
(43, 'Shoplifting'),
(44, 'Solicitation'),
(45, 'Stalking'),
(46, 'Theft'),
(47, 'Vandalism/Criminal Damage'),
(48, 'Other');

-- --------------------------------------------------------

--
-- Table structure for table `missingPerson`
--

CREATE TABLE IF NOT EXISTS `missingPerson` (
  `mpID` int(11) NOT NULL,
  `mpName` varchar(30) NOT NULL,
  `mpAge` int(10) NOT NULL,
  `mpDetails` varchar(50) NOT NULL,
  `mpContact` varchar(12) NOT NULL,
  `missingDate` date NOT NULL,
  `mpImage` varchar(50) DEFAULT NULL,
  `mpStatus` int(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `missingPerson`
--

INSERT INTO `missingPerson` (`mpID`, `mpName`, `mpAge`, `mpDetails`, `mpContact`, `missingDate`, `mpImage`, `mpStatus`) VALUES
(1, 'Jignesh Maradiya', 25, 'Black Hair and fair skin', '9274743999', '2016-05-25', 'null', 1),
(2, 'Bhavesh Rana', 24, 'medium fair skin', '98654743590', '2016-06-10', 'null', 1),
(3, 'Manish Pandey', 29, 'Long Hair and Having tatto on right arm', '7589416960', '2016-06-20', 'null', 1),
(4, 'Sneha Agarwal', 10, 'Fair skin, Long silky hair and weared pink frock', '8456126946', '2016-06-16', 'null', 1),
(5, 'Harpreet Singh', 35, 'Fat, brown eyes and Having tatoo on chest', '99654653414', '2016-06-12', 'null', 1),
(6, 'Pavan Dubey', 47, 'Dark Skin and french beard', '9745665235', '2016-06-19', 'null', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mpFoundLocation`
--

CREATE TABLE IF NOT EXISTS `mpFoundLocation` (
  `mpFLID` int(11) NOT NULL,
  `mpID` int(11) NOT NULL,
  `UID` int(11) NOT NULL,
  `psID` int(11) NOT NULL,
  `latitude` varchar(50) NOT NULL,
  `longitude` varchar(50) NOT NULL,
  `foundLocationAddress` varchar(100) NOT NULL,
  `mpFLDate` date NOT NULL,
  `mpFLTime` time NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mpFoundLocation`
--

INSERT INTO `mpFoundLocation` (`mpFLID`, `mpID`, `UID`, `psID`, `latitude`, `longitude`, `foundLocationAddress`, `mpFLDate`, `mpFLTime`) VALUES
(1, 2, 1, 9, '19.01761470', '72.85616440', 'B/1, Sewari Wadala Road, Mumbai, Maharashtra, India - 400019', '2016-10-05', '12:50:52'),
(2, 2, 1, 9, '19.01761470', '72.85616440', 'B/1, Sewari Wadala Road, Mumbai, Maharashtra, India - 400019', '2016-10-05', '12:51:43'),
(3, 2, 1, 9, '19.01761470', '72.85616440', 'B/1, Sewari Wadala Road, Mumbai, Maharashtra, India - 400019', '2016-10-05', '12:53:45'),
(4, 2, 1, 9, '19.01761470', '72.85616440', 'B/1, Sewari Wadala Road, Mumbai, Maharashtra, India - 400019', '2016-10-05', '12:54:44'),
(5, 6, 1, 9, '19.01761470', '72.85616440', '(null)', '2016-10-08', '11:30:53');

-- --------------------------------------------------------

--
-- Table structure for table `policeOfficialsInfo`
--

CREATE TABLE IF NOT EXISTS `policeOfficialsInfo` (
  `poID` int(11) NOT NULL,
  `psID` int(11) NOT NULL,
  `poName` varchar(50) NOT NULL,
  `poPost` varchar(50) NOT NULL,
  `poContact` varchar(50) NOT NULL,
  `poImage` varchar(100) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `policeOfficialsInfo`
--

INSERT INTO `policeOfficialsInfo` (`poID`, `psID`, `poName`, `poPost`, `poContact`, `poImage`, `status`) VALUES
(1, 1, 'Shri A.M. Captan', 'Police Inspector (P.I.)', '9879509779', 'http://localhost/iWitness_WS/uploads/policeOfficials/PI-Athwa.jpg', 0),
(2, 2, 'Shri G. A. Sarvaiya', 'Police Inspector (P.I.)', '9727754545', 'http://localhost/iWitness_WS/uploads/policeOfficials/PI-Umra.jpg', 0),
(3, 3, 'Shri P.K. Patel', 'Police Inspector (P.I.)', '9825586368', 'http://localhost/iWitness_WS/uploads/policeOfficials/PI-Khatodra.png', 0),
(4, 4, 'Shri P.B. Sapra', 'Police Inspector (P.I.)', '9712009090', 'http://localhost/iWitness_WS/uploads/policeOfficials/PI-Udhana.jpg', 0),
(5, 5, 'Shri D.P. Vaghela', 'Police Inspector (P.I.)', '9913344144', 'http://localhost/iWitness_WS/uploads/policeOfficials/PI-Adajan.png', 0),
(6, 6, 'Shri B.K. Vanar', 'Police Inspector (P.I.)', '9979011100', 'http://localhost/iWitness_WS/uploads/policeOfficials/PI-Salabatpura.png', 0),
(7, 7, 'Shri P.K. Diyora', 'Police Inspector (P.I.)', '9925020128', 'http://localhost/iWitness_WS/uploads/policeOfficials/PI-Katargam.jpg', 0),
(8, 8, 'Shri G.A. Patel', 'Police Inspector (P.I.)', '8980045800', 'http://localhost/iWitness_WS/uploads/policeOfficials/PI-Rander.png', 0),
(9, 9, 'Shri N.L. Desai', 'Police Inspector (P.I.)', '9924466599', 'http://localhost/iWitness_WS/uploads/policeOfficials/PI-Pandesara.png', 0),
(10, 10, 'Shri C.K. Patel', 'Police Inspector (P.I.)', '9879798844', 'http://localhost/iWitness_WS/uploads/policeOfficials/PI-Varachha.png', 0),
(11, 11, 'Shri B.S. Mori', 'Police Inspector (P.I.)', '9879794497', 'http://localhost/iWitness_WS/uploads/policeOfficials/PI-Kapodra.png', 0);

-- --------------------------------------------------------

--
-- Table structure for table `psRegistration`
--

CREATE TABLE IF NOT EXISTS `psRegistration` (
  `psID` int(11) NOT NULL,
  `psName` varchar(50) NOT NULL,
  `psAddress` varchar(70) NOT NULL,
  `psLatitude` varchar(50) NOT NULL,
  `psLongitude` varchar(50) NOT NULL,
  `psUsername` varchar(20) NOT NULL,
  `psPassword` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `psRegistration`
--

INSERT INTO `psRegistration` (`psID`, `psName`, `psAddress`, `psLatitude`, `psLongitude`, `psUsername`, `psPassword`) VALUES
(1, 'Athwa Police Station', 'Ghod Dod Rd, Athwalines, Athwa, Surat, Gujarat-395001', '21.1756607', '72.739673', 'psathwa', 'psathwa'),
(2, 'Umra Police Station', 'NearPolice Pared Ground, Athwalines, Surat, Gujarat 395001', '21.179149', '72.7337117', 'psumra', 'psumra'),
(3, 'Khotdara Police Station', 'Near Jogani Temple, U.M.Road, Udhna, Surat, Gujarat-395002', '21.1758536', '72.7605397', 'pskhotdara', 'pskhotdara'),
(4, 'Udhna Police Station', 'GIDC, Hari Ichchha Industrial Society, Udhna Udhyog Nagar, Surat, Guja', '21.1654721', '72.7803658', 'psudhna', 'psudhna'),
(5, 'Adajan Police Station', 'Adajan Gam, Surat, Gujarat 395009', '21.1907475', '72.7238225', 'psadajan', 'psadajan'),
(6, 'Salabatpura Police Station', ' Salabatpura Main Rd, Surat, Gujarat-395003', '21.1910898', '72.7664676', 'pssalabatpura', 'pssalabatpura'),
(7, 'Katargam Police Station', 'Katargam Main Road, Near Ram Temple, Katargam, Surat, Gujarat-395004', '21.2232639', '72.7631644', 'pskatargam', 'pskatargam'),
(8, 'Rander Police Station', 'Rander, Surat, Gujarat-395005', '21.2183962', '72.7245907', 'psrander', 'psrander'),
(9, 'Pandesara Police Station', 'Pandesara GIDC, Udhna, Surat, Gujarat-394221', '21.1418794', '72.7699651', 'pspandesara', 'pspandesara'),
(10, 'Varachha Police Station', 'Surat - Kamrej Highway, Laxman Nagar, Varachha, Surat, Gujarat-395006', '21.2094003', '72.7795494', 'psvarachha', 'psvarachha'),
(11, 'Kapodra Police Station', 'Nana Varachha Road, Kamrej Highway, Kapodra, Surat, Gujarat-394010', '21.2206162', '72.8055535', 'pskapodra', 'pskapodra');

-- --------------------------------------------------------

--
-- Table structure for table `userRegistration`
--

CREATE TABLE IF NOT EXISTS `userRegistration` (
  `UID` int(11) NOT NULL,
  `UName` varchar(30) NOT NULL,
  `USurname` varchar(30) NOT NULL,
  `UAddress` varchar(100) NOT NULL,
  `UContact` varchar(50) NOT NULL,
  `UEmail` varchar(25) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `UAadharNo` bigint(25) NOT NULL,
  `UProfilePic` varchar(100) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userRegistration`
--

INSERT INTO `userRegistration` (`UID`, `UName`, `USurname`, `UAddress`, `UContact`, `UEmail`, `Username`, `Password`, `UAadharNo`, `UProfilePic`) VALUES
(1, 'Chintan', 'Maisuriya', 'Bhatar, Surat', '7359189897', 'csm@gmail.com', 'csm', 'csm12345', 765834544345, 'http://localhost/iWitness_WS/uploads/ChintanMaisuriya.jpg'),
(2, 'Dhruvit', 'Modi', 'Surat', '8947354545', 'xyz@gmail.com', 'dm', 'dm', 798453143696, 'http://localhost/iWitness_WS/uploads/DhruvitModi.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `wantedPersons`
--

CREATE TABLE IF NOT EXISTS `wantedPersons` (
  `wpID` int(11) NOT NULL,
  `wpName` varchar(50) NOT NULL,
  `wpSex` varchar(10) NOT NULL,
  `wpDOB` date NOT NULL,
  `wpPOB` varchar(30) NOT NULL,
  `languageSpoken` varchar(50) NOT NULL,
  `wpNationality` varchar(30) NOT NULL,
  `wpDetails` varchar(100) NOT NULL,
  `wpCharges` varchar(100) NOT NULL,
  `Reward` varchar(25) NOT NULL,
  `wpImage` varchar(50) NOT NULL,
  `wpStatus` int(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wantedPersons`
--

INSERT INTO `wantedPersons` (`wpID`, `wpName`, `wpSex`, `wpDOB`, `wpPOB`, `languageSpoken`, `wpNationality`, `wpDetails`, `wpCharges`, `Reward`, `wpImage`, `wpStatus`) VALUES
(1, 'Dawood Ibrahim', 'Male', '2055-12-27', 'Khed Ratnagiri, Maharastra', 'Hindi, Urdu, English', 'India', 'Leader of the Indian organised crime syndicate D-Company', 'Cheating, Criminal Conspiracy ', '$25 million', '', 1),
(2, 'Ahmed Maksood', 'Male', '0000-00-00', 'Pakistan', 'Urdu', 'Pakistan', '', 'Murder and Use of Firearms', '', '', 1),
(3, 'Chand Bahadur', 'Male', '1978-01-07', 'Baitali, Nepal', 'Nepali, Hindi, Marathi', 'Nepalese', '', 'Kidnapping, Husband or relative of husband or woman subjecting her cruelty', '', '', 1),
(4, 'Abu Baker', 'Male', '1997-05-07', 'Mumbai, India', 'Hindi, Urdu, Marathi', 'Indian', '165 Cms. Height, Clean Shaven, Scar Below Chin', 'Criminal conspiracy,causing bodily harm,damage to property, murder,terrorist activities', '', '', 1),
(5, 'Maulana Mohamad Masood Azhar Alvi Masood', 'Male', '2068-07-10', 'Bahawalpur, Punjab, Pakistan', 'Urdu, Arabic, Farsi, Punjabi', 'Pakistani', '167 cm Height, Small black mole on forehead', 'Conspiracy to wage war against the State, murder, possessing explosives, arms and ammunition', '', '', 1),
(6, 'Yakub Memon', 'Male', '2062-07-30', 'Mumbai, India', 'Hindi, Urdu', 'Indian', 'Executed by hanging  in Nagpur Central Jail on 30 July 2015 ', '1993 Bombay bombings', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wpFoundLocation`
--

CREATE TABLE IF NOT EXISTS `wpFoundLocation` (
  `wpFLID` int(11) NOT NULL,
  `wpID` int(11) NOT NULL,
  `UID` int(11) NOT NULL,
  `psID` int(11) NOT NULL,
  `latitude` varchar(50) NOT NULL,
  `longitude` varchar(50) NOT NULL,
  `foundLocationAddress` varchar(100) NOT NULL,
  `wpFLDate` date NOT NULL,
  `wpFLTime` time NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wpFoundLocation`
--

INSERT INTO `wpFoundLocation` (`wpFLID`, `wpID`, `UID`, `psID`, `latitude`, `longitude`, `foundLocationAddress`, `wpFLDate`, `wpFLTime`) VALUES
(1, 3, 1, 9, '19.01761470', '72.85616440', 'B/1, Sewari Wadala Road, Mumbai, Maharashtra, India - 400019', '2016-10-08', '11:38:40');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Complaint`
--
ALTER TABLE `Complaint`
  ADD PRIMARY KEY (`cID`);

--
-- Indexes for table `Feedbacks`
--
ALTER TABLE `Feedbacks`
  ADD PRIMARY KEY (`fbID`);

--
-- Indexes for table `Suggestions`
--
ALTER TABLE `Suggestions`
  ADD PRIMARY KEY (`sugID`);

--
-- Indexes for table `crimeTypes`
--
ALTER TABLE `crimeTypes`
  ADD PRIMARY KEY (`ctID`);

--
-- Indexes for table `missingPerson`
--
ALTER TABLE `missingPerson`
  ADD PRIMARY KEY (`mpID`);

--
-- Indexes for table `mpFoundLocation`
--
ALTER TABLE `mpFoundLocation`
  ADD PRIMARY KEY (`mpFLID`);

--
-- Indexes for table `policeOfficialsInfo`
--
ALTER TABLE `policeOfficialsInfo`
  ADD PRIMARY KEY (`poID`);

--
-- Indexes for table `psRegistration`
--
ALTER TABLE `psRegistration`
  ADD PRIMARY KEY (`psID`);

--
-- Indexes for table `userRegistration`
--
ALTER TABLE `userRegistration`
  ADD PRIMARY KEY (`UID`);

--
-- Indexes for table `wantedPersons`
--
ALTER TABLE `wantedPersons`
  ADD PRIMARY KEY (`wpID`);

--
-- Indexes for table `wpFoundLocation`
--
ALTER TABLE `wpFoundLocation`
  ADD PRIMARY KEY (`wpFLID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Complaint`
--
ALTER TABLE `Complaint`
  MODIFY `cID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `Feedbacks`
--
ALTER TABLE `Feedbacks`
  MODIFY `fbID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `Suggestions`
--
ALTER TABLE `Suggestions`
  MODIFY `sugID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `crimeTypes`
--
ALTER TABLE `crimeTypes`
  MODIFY `ctID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=49;
--
-- AUTO_INCREMENT for table `missingPerson`
--
ALTER TABLE `missingPerson`
  MODIFY `mpID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `mpFoundLocation`
--
ALTER TABLE `mpFoundLocation`
  MODIFY `mpFLID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `policeOfficialsInfo`
--
ALTER TABLE `policeOfficialsInfo`
  MODIFY `poID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `psRegistration`
--
ALTER TABLE `psRegistration`
  MODIFY `psID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `userRegistration`
--
ALTER TABLE `userRegistration`
  MODIFY `UID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `wantedPersons`
--
ALTER TABLE `wantedPersons`
  MODIFY `wpID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `wpFoundLocation`
--
ALTER TABLE `wpFoundLocation`
  MODIFY `wpFLID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;--
-- Database: `jsondemo`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl`
--

CREATE TABLE IF NOT EXISTS `tbl` (
  `id` int(3) NOT NULL,
  `name` varchar(50) NOT NULL,
  `contact` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl`
--
ALTER TABLE `tbl`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl`
--
ALTER TABLE `tbl`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT;--
-- Database: `mydatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `mytable`
--

CREATE TABLE IF NOT EXISTS `mytable` (
  `ID` int(3) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Contact` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mytable`
--

INSERT INTO `mytable` (`ID`, `Name`, `Contact`) VALUES
(1, 'Vishal', '9725992972'),
(2, 'Patel', '9909890441');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mytable`
--
ALTER TABLE `mytable`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `Contact` (`Contact`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mytable`
--
ALTER TABLE `mytable`
  MODIFY `ID` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;--
-- Database: `pRince`
--

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE IF NOT EXISTS `cars` (
  `number` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `colour` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`number`, `name`, `colour`) VALUES
(1, 'POLO', 'BLACK'),
(2, 'LIMOSIN', 'WHITE'),
(3, 'LAMBORGINI', 'BLUE');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`number`);
--
-- Database: `phpmyadmin`
--
--
-- Database: `realestate`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE IF NOT EXISTS `tbl_admin` (
  `admin_id` int(11) NOT NULL,
  `admin_uname` varchar(100) NOT NULL,
  `admin_img` text NOT NULL,
  `admin_email` varchar(100) NOT NULL,
  `admin_password` varchar(100) NOT NULL,
  `admin_status` int(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `admin_uname`, `admin_img`, `admin_email`, `admin_password`, `admin_status`) VALUES
(1, 'Vaibhav103', '01.jpg', 'vaibhavakabari10@gmail.com', 'Vaibhav103', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_city`
--

CREATE TABLE IF NOT EXISTS `tbl_city` (
  `ci_id` int(11) NOT NULL,
  `ci_name` varchar(100) NOT NULL,
  `st_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_city`
--

INSERT INTO `tbl_city` (`ci_id`, `ci_name`, `st_id`) VALUES
(1, 'Surat', 1),
(2, 'Vadodara', 1),
(3, 'Rajkot', 1),
(4, 'Anand', 1),
(5, 'Pune', 2),
(6, 'Mumbai', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_country`
--

CREATE TABLE IF NOT EXISTS `tbl_country` (
  `co_id` int(11) NOT NULL,
  `co_name` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_country`
--

INSERT INTO `tbl_country` (`co_id`, `co_name`) VALUES
(1, 'India'),
(2, 'USA'),
(3, 'UK'),
(4, 'Chaina');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pincode`
--

CREATE TABLE IF NOT EXISTS `tbl_pincode` (
  `pi_id` int(11) NOT NULL,
  `pincode` int(11) NOT NULL,
  `ci_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_pincode`
--

INSERT INTO `tbl_pincode` (`pi_id`, `pincode`, `ci_id`) VALUES
(1, 395001, 1),
(2, 395006, 1),
(3, 395002, 1),
(4, 395010, 1),
(5, 391421, 2),
(6, 391111, 2),
(7, 360311, 3),
(8, 360055, 3);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pr_mtype`
--

CREATE TABLE IF NOT EXISTS `tbl_pr_mtype` (
  `pr_mtype_id` int(11) NOT NULL,
  `type_name` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_pr_mtype`
--

INSERT INTO `tbl_pr_mtype` (`pr_mtype_id`, `type_name`) VALUES
(1, 'Residental'),
(2, 'Commercial'),
(3, 'Agricultural'),
(4, 'Industrial'),
(5, 'Rental');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pr_std`
--

CREATE TABLE IF NOT EXISTS `tbl_pr_std` (
  `pr_std_id` int(11) NOT NULL,
  `std_name` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_pr_std`
--

INSERT INTO `tbl_pr_std` (`pr_std_id`, `std_name`) VALUES
(1, 'Luxurious'),
(2, 'Medium'),
(3, 'Local');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pr_type`
--

CREATE TABLE IF NOT EXISTS `tbl_pr_type` (
  `pr_type_id` int(11) NOT NULL,
  `type_name` varchar(100) NOT NULL,
  `pr_mtype_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_pr_type`
--

INSERT INTO `tbl_pr_type` (`pr_type_id`, `type_name`, `pr_mtype_id`) VALUES
(1, 'Residental Land/Plot', 1),
(2, 'Residental House', 1),
(3, 'Villa', 1),
(4, 'Flat/Builder Floor Apartment', 1),
(5, 'Commercial Land/plot', 2),
(6, 'Commercial Office Space', 2),
(7, 'Commercial Shop', 2),
(8, 'Commercial Show-room', 2),
(9, 'Agricultural Land', 3),
(10, 'Farm-House', 3),
(11, 'Industrial Land/Plot', 4),
(12, 'Industrial Building', 4),
(13, 'Industrial Shed', 4),
(15, 'Hotel', 5),
(16, 'Guest House', 5),
(17, 'Business Center', 5),
(18, 'Warehouse', 5),
(19, 'Hostel', 5),
(20, 'Party-Plot', 5),
(21, 'Wedding Hall', 5),
(22, 'Restaurant', 5);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_property_rent`
--

CREATE TABLE IF NOT EXISTS `tbl_property_rent` (
  `pr_id` int(5) NOT NULL,
  `pr_type_id` int(11) NOT NULL,
  `pr_std_id` int(11) NOT NULL,
  `pr_for` varchar(100) NOT NULL DEFAULT 'Rent',
  `pr_post_date` varchar(100) NOT NULL,
  `pr_title` varchar(200) NOT NULL,
  `pr_address` text NOT NULL,
  `pr_co_id` int(11) NOT NULL,
  `pr_st_id` int(11) NOT NULL,
  `pr_ci_id` int(11) NOT NULL,
  `pr_pin_id` int(11) NOT NULL,
  `pr_troom` int(11) NOT NULL,
  `pr_tbroom` int(11) NOT NULL,
  `pr_bwbath` int(11) NOT NULL,
  `pr_tsqft` int(11) NOT NULL,
  `pr_age` int(11) NOT NULL,
  `pr_amenities` text NOT NULL,
  `pr_features` text NOT NULL,
  `pr_rduration` varchar(100) NOT NULL,
  `pr_ramount` int(11) NOT NULL,
  `pr_payopt` varchar(100) NOT NULL,
  `pr_deposite` int(11) NOT NULL,
  `pr_img1` text NOT NULL,
  `pr_img2` text NOT NULL,
  `pr_img3` text NOT NULL,
  `pr_img4` text NOT NULL,
  `pr_img5` text NOT NULL,
  `pr_img6` text NOT NULL,
  `pr_disc` text NOT NULL,
  `pr_tc` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `pr_img_session` int(11) NOT NULL,
  `pr_approval` int(11) NOT NULL,
  `pr_status` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_property_rent`
--

INSERT INTO `tbl_property_rent` (`pr_id`, `pr_type_id`, `pr_std_id`, `pr_for`, `pr_post_date`, `pr_title`, `pr_address`, `pr_co_id`, `pr_st_id`, `pr_ci_id`, `pr_pin_id`, `pr_troom`, `pr_tbroom`, `pr_bwbath`, `pr_tsqft`, `pr_age`, `pr_amenities`, `pr_features`, `pr_rduration`, `pr_ramount`, `pr_payopt`, `pr_deposite`, `pr_img1`, `pr_img2`, `pr_img3`, `pr_img4`, `pr_img5`, `pr_img6`, `pr_disc`, `pr_tc`, `user_id`, `pr_img_session`, `pr_approval`, `pr_status`) VALUES
(1, 2, 3, 'Rent', '13-11-2016', 'title', 'address', 1, 1, 2, 3, 3, 2, 1, 500, 1, 'F,A,T', 'A,F', 'Weekly', 2000, 'C,D', 10000, '', '', '', '', '', '', 'disc', 'tc', 1, 0, 0, 0),
(2, 10, 1, 'Rent', '13-11-2016', 'Green Farm & Villa', 'Akshardham Road, Oop/ Jinal Ground', 1, 1, 2, 5, 3, 2, 1, 1500, 1, 'Air conditioned,Solar Heating,Power Backup,Private Terrace,Cafeteria/Food Court,', 'Airport,Hospital,Market,', 'Daily', 2500, 'Cash,Cheque,', 10000, '', '', '', '', '', '', '', '', 1, 0, 0, 0),
(3, 6, 3, 'Rent', '13-11-2016', 'Offilce Room - 3 Hall', '43-46, Renuka Apartment, Oop/ Gujrat Gas Chowk, Adajan Road', 1, 1, 1, 3, 3, 0, 0, 620, 3, 'Air conditioned,Internet/Wi-Fi,Ground Water,Lift,Security,', 'Railway Station,Shopping Mall,Hospital,Petrol Pump,Market,', 'Monthly', 5000, 'Cheque,', 15000, '', '', '', '', '', '', '', '', 1, 3, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_property_sale`
--

CREATE TABLE IF NOT EXISTS `tbl_property_sale` (
  `pr_id` int(5) NOT NULL,
  `pr_type_id` int(11) NOT NULL,
  `pr_std_id` int(11) NOT NULL,
  `pr_for` varchar(100) NOT NULL DEFAULT 'Sale',
  `pr_post_date` varchar(100) NOT NULL,
  `pr_title` varchar(200) NOT NULL,
  `pr_address` text NOT NULL,
  `pr_co_id` int(11) NOT NULL,
  `pr_st_id` int(11) NOT NULL,
  `pr_ci_id` int(11) NOT NULL,
  `pr_pin_id` int(11) NOT NULL,
  `pr_troom` int(11) NOT NULL,
  `pr_tbroom` int(11) NOT NULL,
  `pr_bwbath` int(11) NOT NULL,
  `pr_tsqft` int(11) NOT NULL,
  `pr_psqft` int(11) NOT NULL,
  `pr_age` int(11) NOT NULL,
  `pr_amenities` text NOT NULL,
  `pr_features` text NOT NULL,
  `pr_payopt` varchar(100) NOT NULL,
  `pr_bforloan` text NOT NULL,
  `pr_tprice` int(11) NOT NULL,
  `pr_dpay` int(11) NOT NULL,
  `pr_img1` text NOT NULL,
  `pr_img2` text NOT NULL,
  `pr_img3` text NOT NULL,
  `pr_img4` text NOT NULL,
  `pr_img5` text NOT NULL,
  `pr_img6` text NOT NULL,
  `pr_disc` text NOT NULL,
  `pr_tc` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `pr_img_session` int(11) NOT NULL,
  `pr_approval` int(11) NOT NULL,
  `pr_status` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_property_sale`
--

INSERT INTO `tbl_property_sale` (`pr_id`, `pr_type_id`, `pr_std_id`, `pr_for`, `pr_post_date`, `pr_title`, `pr_address`, `pr_co_id`, `pr_st_id`, `pr_ci_id`, `pr_pin_id`, `pr_troom`, `pr_tbroom`, `pr_bwbath`, `pr_tsqft`, `pr_psqft`, `pr_age`, `pr_amenities`, `pr_features`, `pr_payopt`, `pr_bforloan`, `pr_tprice`, `pr_dpay`, `pr_img1`, `pr_img2`, `pr_img3`, `pr_img4`, `pr_img5`, `pr_img6`, `pr_disc`, `pr_tc`, `user_id`, `pr_img_session`, `pr_approval`, `pr_status`) VALUES
(1, 3, 1, 'Sale', '12-11-2016', 'High Party Plot', '12-13, Asharam Plot, Varachha road', 1, 1, 1, 2, 10, 5, 2, 1500, 15000, 2, 'Air conditioned,Solar Heating,Power Backup,RO Water System,Laundary Service,Lift,Maintanance Staff,', 'School,College,Shopping Mall,Hospital,Petrol Pump,Market,', 'Loan', 'State Bank of India,HDFC,Saraswat Bank,Union Bank of India,', 5000000, 700000, '', '', '', '', '', '', '', '', 11, 0, 0, 0),
(2, 11, 2, 'Sale', '13-11-2016', 'Martine Land', 'Martin Plot, Piplod Road', 1, 1, 1, 2, 0, 0, 0, 1800, 5000, 2, 'Servant Quaters,Power Backup,Water Storage,Maintanance Staff,Garden,Visitor Parking,', 'School,College,Hospital,Petrol Pump,Market,', 'Loan', 'State Bank of India,HDFC,Saraswat Bank,Union Bank of India,', 5000000, 700000, '51.jpg', '13.jpg', '61.jpg', '105.jpg', '44.jpg', '123.jpg', '', '', 1, 1, 0, 0),
(3, 16, 1, 'Sale', '13-11-2016', 'Golden Home', '23,24, Golden Plot, Asharam Road', 1, 1, 1, 2, 10, 6, 2, 1200, 23000, 2, 'Air conditioned,Servant Quaters,Banquet Hall,Pipe Gas,Swimming Pool,DTH Television,Power Backup,Private Terrace,Intercom Facility,RO Water System,Laundary Service,Lift,Maintanance Staff,Garden,Gymnasium,', 'School,Shopping Mall,Hospital,Bank/ATM,Grocery Store,Market,Theatre,', 'Monthly Installment', 'State Bank of India,ICICI,Varachha,Saraswat Bank,', 5200000, 800000, '102.jpg', '11.jpg', '10.jpg', '46.jpg', '157.jpg', '169.jpg', '', '', 1, 1, 0, 0),
(28, 5, 2, 'Sale', '13-11-2016', 'vfvfvf', 'fvfvfvfvf', 1, 1, 3, 7, 3, 2, 1, 500, 5000, 1, 'Air conditioned,Muncipal Water Supply,', 'School,Railway Station,', 'Cash', 'State Bank of India,ICICI,Varachha,Saraswat Bank,', 2000000, 100000, '', '', '', '', '', '', '', '', 1, 3, 0, 0),
(29, 5, 2, 'Sale', '13-11-2016', 'vfvfvf', 'fvfvfvfvf', 1, 1, 3, 7, 3, 2, 1, 500, 5000, 1, 'Air conditioned,Muncipal Water Supply,', 'School,Railway Station,', 'Cash', 'State Bank of India,ICICI,Varachha,Saraswat Bank,', 2000000, 100000, '', '', '', '', '', '', '', '', 1, 4, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_req_buy`
--

CREATE TABLE IF NOT EXISTS `tbl_req_buy` (
  `rq_id` int(11) NOT NULL,
  `pr_type_id` int(11) NOT NULL,
  `pr_std_id` int(11) NOT NULL,
  `rq_for` varchar(100) NOT NULL DEFAULT 'Sale',
  `rq_post_date` varchar(100) NOT NULL,
  `rq_co_id` int(11) NOT NULL,
  `rq_st_id` int(11) NOT NULL,
  `rq_ci_id` int(11) NOT NULL,
  `rq_pin_id` int(11) NOT NULL,
  `rq_troom` int(11) NOT NULL,
  `rq_tbroom` int(11) NOT NULL,
  `rq_bwbath` int(11) NOT NULL,
  `rq_plimit` int(11) NOT NULL,
  `rq_alimit` int(11) NOT NULL,
  `rq_page` int(11) NOT NULL,
  `rq_payopt` varchar(100) NOT NULL,
  `rq_dlimit` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rq_approval` int(11) NOT NULL,
  `rq_status` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_req_buy`
--

INSERT INTO `tbl_req_buy` (`rq_id`, `pr_type_id`, `pr_std_id`, `rq_for`, `rq_post_date`, `rq_co_id`, `rq_st_id`, `rq_ci_id`, `rq_pin_id`, `rq_troom`, `rq_tbroom`, `rq_bwbath`, `rq_plimit`, `rq_alimit`, `rq_page`, `rq_payopt`, `rq_dlimit`, `user_id`, `rq_approval`, `rq_status`) VALUES
(1, 2, 3, 'Sale', '13-11-2016', 1, 1, 2, 1, 3, 2, 1, 2000000, 300, 1, 'Cash', 250000, 2, 0, 0),
(2, 2, 2, 'Sale', '13-11-2016', 1, 1, 2, 1, 3, 2, 1, 2000000, 300, 2, 'Cash', 200000, 2, 0, 0),
(3, 2, 1, 'Sale', '13-11-2016', 1, 1, 1, 1, 3, 2, 1, 2000000, 300, 1, 'Loan', 200000, 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_req_rent`
--

CREATE TABLE IF NOT EXISTS `tbl_req_rent` (
  `rq_id` int(11) NOT NULL,
  `pr_type_id` int(11) NOT NULL,
  `pr_std_id` int(11) NOT NULL,
  `rq_for` varchar(100) NOT NULL DEFAULT 'Rent',
  `rq_post_date` varchar(100) NOT NULL,
  `rq_country` varchar(100) NOT NULL,
  `rq_state` varchar(100) NOT NULL,
  `rq_city` varchar(100) NOT NULL,
  `rq_pincode` int(6) NOT NULL,
  `rq_troom` int(11) NOT NULL,
  `rq_tbroom` int(11) NOT NULL,
  `rq_bwbath` int(11) NOT NULL,
  `rq_alimit` int(11) NOT NULL,
  `rq_page` int(11) NOT NULL,
  `rq_paydur` varchar(100) NOT NULL,
  `rq_payopt` varchar(100) NOT NULL,
  `rq_ralimit` int(11) NOT NULL,
  `rq_dlimit` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rq_approval` int(11) NOT NULL,
  `rq_status` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_req_rent`
--

INSERT INTO `tbl_req_rent` (`rq_id`, `pr_type_id`, `pr_std_id`, `rq_for`, `rq_post_date`, `rq_country`, `rq_state`, `rq_city`, `rq_pincode`, `rq_troom`, `rq_tbroom`, `rq_bwbath`, `rq_alimit`, `rq_page`, `rq_paydur`, `rq_payopt`, `rq_ralimit`, `rq_dlimit`, `user_id`, `rq_approval`, `rq_status`) VALUES
(1, 2, 3, 'Rent', '13-11-2016', '2', '2', '1', 2, 3, 2, 1, 300, 1, 'Weekly', 'Cash', 2000, 10000, 1, 0, 0),
(2, 15, 2, 'Rent', '13-11-2016', '1', '1', '1', 1, 10, 6, 1, 1500, 1, 'Daily', '', 2000, 10000, 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_state`
--

CREATE TABLE IF NOT EXISTS `tbl_state` (
  `st_id` int(11) NOT NULL,
  `st_name` varchar(100) NOT NULL,
  `co_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_state`
--

INSERT INTO `tbl_state` (`st_id`, `st_name`, `co_id`) VALUES
(1, 'Gujarat', 1),
(2, 'Maharashtra', 1),
(3, 'California', 2),
(4, 'Delaware', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sys_user`
--

CREATE TABLE IF NOT EXISTS `tbl_sys_user` (
  `user_id` int(5) NOT NULL,
  `user_type_id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `user_fname` varchar(100) NOT NULL,
  `user_lname` varchar(100) NOT NULL,
  `user_address` text NOT NULL,
  `user_co_id` int(11) NOT NULL,
  `user_st_id` int(11) NOT NULL,
  `user_ci_id` int(11) NOT NULL,
  `user_pin_id` int(11) NOT NULL,
  `user_mono` int(10) NOT NULL,
  `user_dob` varchar(100) NOT NULL,
  `user_gender` varchar(1) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_password` varchar(500) NOT NULL,
  `user_photo` text NOT NULL,
  `user_status` int(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_sys_user`
--

INSERT INTO `tbl_sys_user` (`user_id`, `user_type_id`, `user_name`, `user_fname`, `user_lname`, `user_address`, `user_co_id`, `user_st_id`, `user_ci_id`, `user_pin_id`, `user_mono`, `user_dob`, `user_gender`, `user_email`, `user_password`, `user_photo`, `user_status`) VALUES
(1, 1, 'vaibhav103', 'Vaibhav', 'Akabari', '', 0, 0, 0, 0, 0, '', '', 'vaibhavakabari10@gmail.com', 'c132a5a8c60ae648d0f74cda04b24280', '', 0),
(2, 1, '', 'Mayur', 'More', '', 0, 0, 0, 0, 0, '', '', 'mayur123@gmail.com', 'Mayur123', '', 0),
(3, 1, '', 'Rajnik', 'Savant', '', 0, 0, 0, 0, 0, '', '', 'rajnisavant@yahoo.co.in', 'b4bc914c88ca376f8f46aa85b1689900', '', 0),
(4, 1, '', 'Maahi', 'Roy', '', 0, 0, 0, 0, 0, '', '', 'maahiroy12@gmail.com', 'dafa3dbeaaa0ff7618a4237dab03fe47', '', 0),
(5, 1, '', 'Kishor', 'Gawde', '', 0, 0, 0, 0, 0, '', '', 'kishor123@gmail.com', '02d6cbab843c25599cf89365624d4e2b', '', 0),
(11, 1, '', 'My', 'Man', '', 0, 0, 0, 0, 0, '', '', 'myman12@gmail.com', '7bf981fab8ee96b332b37b81f02262ac', '', 0),
(12, 1, '', 'vishal', 'vaghasiya', '', 0, 0, 0, 0, 0, '', '', 'vaghasiya907@gmail.com', '25d55ad283aa400af464c76d713c07ad', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_type`
--

CREATE TABLE IF NOT EXISTS `tbl_user_type` (
  `user_type_id` int(11) NOT NULL,
  `type_name` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user_type`
--

INSERT INTO `tbl_user_type` (`user_type_id`, `type_name`) VALUES
(1, 'Individual'),
(2, 'Agent'),
(3, 'Builder');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tbl_city`
--
ALTER TABLE `tbl_city`
  ADD PRIMARY KEY (`ci_id`),
  ADD KEY `st_id` (`st_id`);

--
-- Indexes for table `tbl_country`
--
ALTER TABLE `tbl_country`
  ADD PRIMARY KEY (`co_id`);

--
-- Indexes for table `tbl_pincode`
--
ALTER TABLE `tbl_pincode`
  ADD PRIMARY KEY (`pi_id`),
  ADD KEY `ci_id` (`ci_id`);

--
-- Indexes for table `tbl_pr_mtype`
--
ALTER TABLE `tbl_pr_mtype`
  ADD PRIMARY KEY (`pr_mtype_id`);

--
-- Indexes for table `tbl_pr_std`
--
ALTER TABLE `tbl_pr_std`
  ADD PRIMARY KEY (`pr_std_id`);

--
-- Indexes for table `tbl_pr_type`
--
ALTER TABLE `tbl_pr_type`
  ADD PRIMARY KEY (`pr_type_id`),
  ADD KEY `pr_mtype_id` (`pr_mtype_id`);

--
-- Indexes for table `tbl_property_rent`
--
ALTER TABLE `tbl_property_rent`
  ADD PRIMARY KEY (`pr_id`),
  ADD KEY `pr_std_id` (`pr_std_id`),
  ADD KEY `pr_type_id` (`pr_type_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tbl_property_sale`
--
ALTER TABLE `tbl_property_sale`
  ADD PRIMARY KEY (`pr_id`),
  ADD KEY `pr_std_id` (`pr_std_id`),
  ADD KEY `pr_type_id` (`pr_type_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tbl_req_buy`
--
ALTER TABLE `tbl_req_buy`
  ADD PRIMARY KEY (`rq_id`);

--
-- Indexes for table `tbl_req_rent`
--
ALTER TABLE `tbl_req_rent`
  ADD PRIMARY KEY (`rq_id`);

--
-- Indexes for table `tbl_state`
--
ALTER TABLE `tbl_state`
  ADD PRIMARY KEY (`st_id`),
  ADD KEY `co_id` (`co_id`);

--
-- Indexes for table `tbl_sys_user`
--
ALTER TABLE `tbl_sys_user`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `user_type_id` (`user_type_id`),
  ADD KEY `user_type_id_2` (`user_type_id`),
  ADD KEY `co_id` (`user_co_id`),
  ADD KEY `st_id` (`user_st_id`),
  ADD KEY `ci_id` (`user_ci_id`);

--
-- Indexes for table `tbl_user_type`
--
ALTER TABLE `tbl_user_type`
  ADD PRIMARY KEY (`user_type_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_city`
--
ALTER TABLE `tbl_city`
  MODIFY `ci_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tbl_country`
--
ALTER TABLE `tbl_country`
  MODIFY `co_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_pincode`
--
ALTER TABLE `tbl_pincode`
  MODIFY `pi_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbl_pr_mtype`
--
ALTER TABLE `tbl_pr_mtype`
  MODIFY `pr_mtype_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tbl_pr_std`
--
ALTER TABLE `tbl_pr_std`
  MODIFY `pr_std_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_pr_type`
--
ALTER TABLE `tbl_pr_type`
  MODIFY `pr_type_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `tbl_property_rent`
--
ALTER TABLE `tbl_property_rent`
  MODIFY `pr_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_property_sale`
--
ALTER TABLE `tbl_property_sale`
  MODIFY `pr_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `tbl_req_buy`
--
ALTER TABLE `tbl_req_buy`
  MODIFY `rq_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_req_rent`
--
ALTER TABLE `tbl_req_rent`
  MODIFY `rq_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_state`
--
ALTER TABLE `tbl_state`
  MODIFY `st_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_sys_user`
--
ALTER TABLE `tbl_sys_user`
  MODIFY `user_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `tbl_user_type`
--
ALTER TABLE `tbl_user_type`
  MODIFY `user_type_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_city`
--
ALTER TABLE `tbl_city`
  ADD CONSTRAINT `tbl_city_ibfk_1` FOREIGN KEY (`st_id`) REFERENCES `tbl_state` (`st_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_pincode`
--
ALTER TABLE `tbl_pincode`
  ADD CONSTRAINT `tbl_pincode_ibfk_1` FOREIGN KEY (`ci_id`) REFERENCES `tbl_city` (`ci_id`);

--
-- Constraints for table `tbl_pr_type`
--
ALTER TABLE `tbl_pr_type`
  ADD CONSTRAINT `tbl_pr_type_ibfk_1` FOREIGN KEY (`pr_mtype_id`) REFERENCES `tbl_pr_mtype` (`pr_mtype_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_property_rent`
--
ALTER TABLE `tbl_property_rent`
  ADD CONSTRAINT `tbl_property_rent_ibfk_1` FOREIGN KEY (`pr_type_id`) REFERENCES `tbl_pr_type` (`pr_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_property_rent_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `tbl_sys_user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_property_rent_ibfk_4` FOREIGN KEY (`pr_std_id`) REFERENCES `tbl_pr_std` (`pr_std_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_property_sale`
--
ALTER TABLE `tbl_property_sale`
  ADD CONSTRAINT `tbl_property_sale_ibfk_1` FOREIGN KEY (`pr_std_id`) REFERENCES `tbl_pr_std` (`pr_std_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_property_sale_ibfk_5` FOREIGN KEY (`pr_type_id`) REFERENCES `tbl_pr_type` (`pr_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_property_sale_ibfk_9` FOREIGN KEY (`user_id`) REFERENCES `tbl_sys_user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_state`
--
ALTER TABLE `tbl_state`
  ADD CONSTRAINT `tbl_state_ibfk_1` FOREIGN KEY (`co_id`) REFERENCES `tbl_country` (`co_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_sys_user`
--
ALTER TABLE `tbl_sys_user`
  ADD CONSTRAINT `tbl_sys_user_ibfk_1` FOREIGN KEY (`user_type_id`) REFERENCES `tbl_user_type` (`user_type_id`) ON DELETE CASCADE ON UPDATE CASCADE;
--
-- Database: `samdamo`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
  `id` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Address` varchar(1000) NOT NULL,
  `Mob` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `Name`, `Address`, `Mob`) VALUES
(1, 'Hardik', 'Surat', '9979285789'),
(2, 'Hardik', 'Surat', '9979285789'),
(3, 'hired', 'godhara', '9876543210');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `catagory_tbl`
--

CREATE TABLE IF NOT EXISTS `catagory_tbl` (
  `catagory_id` varchar(50) NOT NULL,
  `catagory_type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `name`
--

CREATE TABLE IF NOT EXISTS `name` (
  `id` int(10) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `name`
--

INSERT INTO `name` (`id`, `firstname`, `lastname`, `email`, `password`) VALUES
(1, 'rocky', 'patel', 'rp@gmail.com', '1234'),
(2, 'rohan', 'patel', 'rp1@gmail.com', '1234'),
(3, 'nd', 'patel', 'np', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `id` int(11) NOT NULL,
  `productname` varchar(50) NOT NULL,
  `productdetail` varchar(50) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product_tbl`
--

CREATE TABLE IF NOT EXISTS `product_tbl` (
  `product_id` varchar(50) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `product_brand` varchar(50) NOT NULL,
  `product_style` varchar(50) NOT NULL,
  `product_price` int(11) NOT NULL,
  `product_size` int(11) NOT NULL,
  `product_offer` varchar(50) NOT NULL,
  `product_info` varchar(100) NOT NULL,
  `product_img` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_tbl`
--

INSERT INTO `product_tbl` (`product_id`, `product_name`, `product_brand`, `product_style`, `product_price`, `product_size`, `product_offer`, `product_info`, `product_img`) VALUES
('1001J1', 'FFSH', 'F & F', 'Slim Fit', 1500, 28, '10% off', 'Slim fit Glenn An updated slim fit with a tapered.', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `name`
--
ALTER TABLE `name`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `name`
--
ALTER TABLE `name`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;--
-- Database: `tiffin_box`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_tiffin_detail`
--

CREATE TABLE IF NOT EXISTS `add_tiffin_detail` (
  `t_id` int(11) NOT NULL,
  `t_name` int(11) NOT NULL,
  `t_image` int(11) NOT NULL,
  `n_of_item` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `des` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `assign_detail`
--

CREATE TABLE IF NOT EXISTS `assign_detail` (
  `a_id` int(11) NOT NULL,
  `a_d_id` int(11) NOT NULL,
  `o_id` int(11) NOT NULL,
  `d&t` date NOT NULL,
  `des` varchar(1000) NOT NULL,
  `t_number` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `delivery_deatil`
--

CREATE TABLE IF NOT EXISTS `delivery_deatil` (
  `d_id` int(11) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `mob` int(11) NOT NULL,
  `status` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `discount_detail`
--

CREATE TABLE IF NOT EXISTS `discount_detail` (
  `d_id` int(11) NOT NULL,
  `o_id` int(11) NOT NULL,
  `p_discount` int(11) NOT NULL,
  `d&t` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE IF NOT EXISTS `order_detail` (
  `o_id` int(11) NOT NULL,
  `t_id` int(11) NOT NULL,
  `d&t` datetime NOT NULL,
  `des` varchar(1000) NOT NULL,
  `t_number` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_review`
--

CREATE TABLE IF NOT EXISTS `user_review` (
  `r_id` int(11) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `rating` varchar(100) NOT NULL,
  `des` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Database: `tifflunbox`
--

-- --------------------------------------------------------

--
-- Table structure for table `Complite_delivery_detail`
--

CREATE TABLE IF NOT EXISTS `Complite_delivery_detail` (
  `c_d_id` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `D_registraion`
--

CREATE TABLE IF NOT EXISTS `D_registraion` (
  `Del_id` int(200) NOT NULL,
  `del_email` varchar(200) NOT NULL,
  `del_name` varchar(200) NOT NULL,
  `del_password` varchar(200) NOT NULL,
  `del_address` varchar(200) NOT NULL,
  `city` varchar(200) NOT NULL,
  `street` varchar(200) NOT NULL,
  `del_phonno` varchar(200) NOT NULL,
  `draiving_licence` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `D_registraion`
--

INSERT INTO `D_registraion` (`Del_id`, `del_email`, `del_name`, `del_password`, `del_address`, `city`, `street`, `del_phonno`, `draiving_licence`) VALUES
(1, 'nsurti21@gmail.com', '', 'Nrs12345', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `Ragistration`
--

CREATE TABLE IF NOT EXISTS `Ragistration` (
  `user_id` int(200) NOT NULL,
  `user_email` varchar(200) NOT NULL,
  `user_password` varchar(200) NOT NULL,
  `user_img` varchar(200) NOT NULL,
  `user_name` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `city` varchar(200) NOT NULL,
  `pincoad` varchar(200) NOT NULL,
  `phno` varchar(200) NOT NULL,
  `identity` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Ragistration`
--

INSERT INTO `Ragistration` (`user_id`, `user_email`, `user_password`, `user_img`, `user_name`, `address`, `city`, `pincoad`, `phno`, `identity`) VALUES
(1, 'nsabhaya11@gmail.com', 'Nik12345', 'rguser_img/58db54511478a.png', 'nikunj', 'Xyz', 'surat', '395004', '8153003181', ''),
(2, 'vivek@gmail.com', 'Vv123456', '', '', '', '', '', '', ''),
(3, 'vir@gmail.com', 'Vr123456', 'rguser_img/58e1dc7cdb42d.png', 'vir', 'xyz', 'surat', '395004', '1234567922', ''),
(4, 'nikunj@gmail.com', '', '', '', '', '', '', '', ''),
(5, 'nikunj@gmail.com', '', '', '', '', '', '', '', ''),
(6, 'nikunj@gmail.com', '', '', '', '', '', '', '', ''),
(7, 'nikunj@gmail.com', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `food_order`
--

CREATE TABLE IF NOT EXISTS `food_order` (
  `sr_no` int(200) NOT NULL,
  `order_id` int(200) NOT NULL,
  `sp_id` int(200) NOT NULL,
  `user_email` varchar(200) NOT NULL,
  `item_name` varchar(200) NOT NULL,
  `item_price` int(200) NOT NULL,
  `tc_type` varchar(200) NOT NULL,
  `quntity` int(200) NOT NULL,
  `item_img` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `food_order`
--

INSERT INTO `food_order` (`sr_no`, `order_id`, `sp_id`, `user_email`, `item_name`, `item_price`, `tc_type`, `quntity`, `item_img`) VALUES
(1, 5911, 1, 'vir@gmail.com', 'Veg masala', 80, 'Gujarati', 3, 'item_images/58e3380332a49.png'),
(2, 5911, 1, 'vir@gmail.com', 'Veg masala', 80, 'Gujarati', 3, 'item_images/58e3380332a49.png'),
(3, 6011, 1, 'vir@gmail.com', 'Veg masala', 80, 'Gujarati', 3, 'item_images/58e3380332a49.png'),
(4, 6011, 1, 'vir@gmail.com', 'Veg masala', 80, 'Gujarati', 3, 'item_images/58e3380332a49.png'),
(5, 6011, 1, 'vir@gmail.com', 'Punjabi raice', 100, 'Panjabi', 1, 'item_images/58e33a8d5f200.png'),
(6, 6011, 1, 'vir@gmail.com', 'Punjabi raice', 100, 'Panjabi', 2, 'item_images/58e33a8d5f200.png'),
(7, 6011, 1, 'vir@gmail.com', 'Veg masala', 80, 'Gujarati', 1, 'item_images/58e3380332a49.png'),
(8, 6011, 1, 'vir@gmail.com', 'Veg burger', 170, 'Italian', 2, 'item_images/58e33d3daedb4.png'),
(9, 5211, 1, 'vir@gmail.com', 'Bengan masala', 60, 'Gujarati', 2, 'item_images/58e338b5f0493.png'),
(10, 5211, 1, 'vir@gmail.com', 'Gujarati raice', 50, 'Gujarati', 1, 'item_images/58e3388780520.png'),
(11, 5211, 1, 'vir@gmail.com', 'Dal tadka with chilies', 130, 'Gujarati', 2, 'item_images/58e3391177e60.png'),
(12, 4905, 1, 'nikunj@gmail.com', 'Punjabi raice', 100, 'Panjabi', 2, 'item_images/58e33a8d5f200.png'),
(13, 4905, 1, 'nikunj@gmail.com', 'Punjabi roll', 220, 'Panjabi', 1, 'item_images/58e33ae149bb9.png'),
(14, 4105, 1, 'nikunj@gmail.com', 'Gujarati raice', 50, 'Gujarati', 1, 'item_images/58e3388780520.png'),
(15, 4105, 1, 'nikunj@gmail.com', 'Veg masala', 80, 'Gujarati', 1, 'item_images/58e3380332a49.png'),
(16, 5705, 1, 'nikunj@gmail.com', 'Veg burger', 170, 'Italian', 1, 'item_images/58e33d3daedb4.png'),
(17, 5705, 1, 'nikunj@gmail.com', 'Focaccia Bread', 450, 'Italian', 1, 'item_images/58e33cd677ae0.png'),
(18, 3605, 1, 'nikunj@gmail.com', 'Veg masala', 80, 'Gujarati', 1, 'item_images/58e3380332a49.png'),
(19, 4205, 1, 'nikunj@gmail.com', 'Bengan masala', 60, 'Gujarati', 1, 'item_images/58e338b5f0493.png'),
(20, 5206, 1, 'nikunj@gmail.com', 'Gujarati raice', 50, 'Gujarati', 0, 'item_images/58e3388780520.png'),
(21, 5206, 1, 'nikunj@gmail.com', 'Bengan masala', 60, 'Gujarati', 0, 'item_images/58e338b5f0493.png'),
(22, 5206, 1, 'nikunj@gmail.com', 'Dal tadka with chilies', 130, 'Gujarati', 0, 'item_images/58e3391177e60.png'),
(23, 3311, 1, 'nikunj@gmail.com', 'Alu Sabji', 60, 'Gujarati', 0, 'item_images/58e339d035c7d.png'),
(24, 3311, 1, 'nikunj@gmail.com', 'Alu Sabji', 60, 'Gujarati', 0, 'item_images/58e339d035c7d.png'),
(25, 3311, 1, 'nikunj@gmail.com', 'Alu Sabji', 60, 'Gujarati', 0, 'item_images/58e339d035c7d.png'),
(26, 3311, 1, 'nikunj@gmail.com', 'Alu Sabji', 60, 'Gujarati', 0, 'item_images/58e339d035c7d.png'),
(27, 5211, 1, 'nikunj@gmail.com', 'Alu Sabji', 60, 'Gujarati', 0, 'item_images/58e339d035c7d.png'),
(28, 5211, 1, 'nikunj@gmail.com', 'Alu Sabji', 60, 'Gujarati', 0, 'item_images/58e339d035c7d.png'),
(29, 3511, 1, 'nikunj@gmail.com', 'Alu Sabji', 60, 'Gujarati', 3, 'item_images/58e339d035c7d.png'),
(30, 3511, 1, 'nikunj@gmail.com', 'Punjabi raice', 100, 'Panjabi', 2, 'item_images/58e33a8d5f200.png'),
(31, 3112, 1, 'nikunj@gmail.com', 'Alu Sabji', 60, 'Gujarati', 2, 'item_images/58e339d035c7d.png'),
(32, 5112, 1, 'nikunj@gmail.com', 'Alu Sabji', 60, 'Gujarati', 2, 'item_images/58e339d035c7d.png'),
(33, 3312, 1, 'nikunj@gmail.com', 'Alu Sabji', 60, 'Gujarati', 4, 'item_images/58e339d035c7d.png'),
(34, 4312, 1, 'nikunj@gmail.com', 'Alu Sabji', 60, 'Gujarati', 2, 'item_images/58e339d035c7d.png'),
(35, 5914, 1, 'nikunj@gmail.com', 'Alu Sabji', 60, 'Gujarati', 3, 'item_images/58e339d035c7d.png'),
(36, 5914, 1, 'nikunj@gmail.com', 'Alu Sabji', 60, 'Gujarati', 2, 'item_images/58e339d035c7d.png'),
(37, 3914, 1, 'nsabhaya11@gmail.com', 'Kaju kari', 140, 'Panjabi', 2, 'item_images/58e33a46600d3.png'),
(38, 3914, 1, 'nsabhaya11@gmail.com', 'Punjabi raice', 100, 'Panjabi', 1, 'item_images/58e33a8d5f200.png');

-- --------------------------------------------------------

--
-- Table structure for table `food_order_detail`
--

CREATE TABLE IF NOT EXISTS `food_order_detail` (
  `f_d_id` int(200) NOT NULL,
  `order_id` int(200) NOT NULL,
  `sp_id` int(200) NOT NULL,
  `user_email` varchar(200) NOT NULL,
  `totalbill` varchar(200) NOT NULL,
  `datetime` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  `Street_address` varchar(200) NOT NULL,
  `city` varchar(200) NOT NULL,
  `state` varchar(200) NOT NULL,
  `Pincoad` varchar(200) NOT NULL,
  `phno` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `food_order_detail`
--

INSERT INTO `food_order_detail` (`f_d_id`, `order_id`, `sp_id`, `user_email`, `totalbill`, `datetime`, `status`, `Street_address`, `city`, `state`, `Pincoad`, `phno`) VALUES
(2, 3914, 1, 'nsabhaya11@gmail.com', '380', '14-05-201721:32', 'On The way', 'Xyz', 'surat', 'surat', '395004', '8153003181');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE IF NOT EXISTS `images` (
  `img_id` int(200) NOT NULL,
  `sp_id` int(200) NOT NULL,
  `images` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`img_id`, `sp_id`, `images`) VALUES
(4, 1, 'images/58e33c169bfda.png'),
(5, 1, 'images/58e33c274bc07.png');

-- --------------------------------------------------------

--
-- Table structure for table `offer`
--

CREATE TABLE IF NOT EXISTS `offer` (
  `offer_id` int(200) NOT NULL,
  `sp_id` int(200) NOT NULL,
  `offer_name` varchar(50) NOT NULL,
  `offer_detail` varchar(50) NOT NULL,
  `offer_img` varchar(200) NOT NULL,
  `old_price` int(200) NOT NULL,
  `new_price` int(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `offer`
--

INSERT INTO `offer` (`offer_id`, `sp_id`, `offer_name`, `offer_detail`, `offer_img`, `old_price`, `new_price`) VALUES
(2, 1, 'Discount', 'Discount offer', 'offerimg/58e33bb95793e.png', 500, 450);

-- --------------------------------------------------------

--
-- Table structure for table `payment_detail`
--

CREATE TABLE IF NOT EXISTS `payment_detail` (
  `payment_id` int(200) NOT NULL,
  `order_id` int(200) NOT NULL,
  `sp_id` int(200) NOT NULL,
  `user_email` varchar(200) NOT NULL,
  `payment_type` varchar(200) NOT NULL,
  `total_bill` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sp_ragistration`
--

CREATE TABLE IF NOT EXISTS `sp_ragistration` (
  `sp_id` int(200) NOT NULL,
  `sp_email` varchar(200) NOT NULL,
  `sp_username` varchar(200) NOT NULL,
  `sp_password` varchar(200) NOT NULL,
  `main_img` varchar(200) NOT NULL,
  `form_name` varchar(200) NOT NULL,
  `form_address` varchar(200) NOT NULL,
  `form_phoneno` varchar(200) NOT NULL,
  `street` varchar(200) NOT NULL,
  `city` varchar(200) NOT NULL,
  `pincoad` varchar(200) NOT NULL,
  `license` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sp_ragistration`
--

INSERT INTO `sp_ragistration` (`sp_id`, `sp_email`, `sp_username`, `sp_password`, `main_img`, `form_name`, `form_address`, `form_phoneno`, `street`, `city`, `pincoad`, `license`) VALUES
(1, 'nrs@gmail.com', 'nrs', 'Nrs12345', 'sp_img/58e3370ee7b13.png', 'GIUSEPPIS', '12 CHAINA TOEN ', '8153003181', 'katargam', 'surat', '395004', ''),
(2, 'Vir@gmail.com', 'vir', 'Vi123456', 'sp_img/58e33dee4954c.png', 'THE ROYAL CHEF', 'VALSAD', '9123451211', 'VALSAD', 'valsad', '', ''),
(3, 'rhs@gmail.com', 'Rhs', 'Rhs12345', 'sp_img/58e33ea0d935a.png', 'TOSCANA', 'AHEMDABAD', '8153000511', 'Setelite', 'Ahemdabad', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tiffin_categaries`
--

CREATE TABLE IF NOT EXISTS `tiffin_categaries` (
  `tc_id` int(200) NOT NULL,
  `sp_id` int(200) NOT NULL,
  `tc_type` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tiffin_categaries`
--

INSERT INTO `tiffin_categaries` (`tc_id`, `sp_id`, `tc_type`) VALUES
(1, 1, 'Gujarati'),
(2, 1, 'Panjabi'),
(3, 1, 'Italian');

-- --------------------------------------------------------

--
-- Table structure for table `tiffin_items`
--

CREATE TABLE IF NOT EXISTS `tiffin_items` (
  `item_id` int(200) NOT NULL,
  `sp_id` int(200) NOT NULL,
  `tc_type` varchar(200) NOT NULL,
  `item_img` varchar(200) NOT NULL,
  `item_name` varchar(200) NOT NULL,
  `item_detail` varchar(200) NOT NULL,
  `item_price` int(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tiffin_items`
--

INSERT INTO `tiffin_items` (`item_id`, `sp_id`, `tc_type`, `item_img`, `item_name`, `item_detail`, `item_price`) VALUES
(6, 1, 'Gujarati', 'item_images/58e339d035c7d.png', 'Alu Sabji', 'This is alu sabji', 60),
(7, 1, 'Panjabi', 'item_images/58e33a46600d3.png', 'Kaju kari', 'This is kaju kari', 140),
(8, 1, 'Panjabi', 'item_images/58e33a8d5f200.png', 'Punjabi raice', 'This is Punjabi raice', 100),
(10, 1, 'Italian', 'item_images/58e33cd677ae0.png', 'Focaccia Bread', 'This is Focaccia Bread', 450),
(11, 1, 'Italian', 'item_images/58e33d3daedb4.png', 'Veg burger', 'This is veg burger', 170);

-- --------------------------------------------------------

--
-- Table structure for table `user_msg`
--

CREATE TABLE IF NOT EXISTS `user_msg` (
  `msg_id` int(200) NOT NULL,
  `sp_id` int(200) NOT NULL,
  `user_name` varchar(200) NOT NULL,
  `user_img` varchar(200) NOT NULL,
  `msg` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_msg`
--

INSERT INTO `user_msg` (`msg_id`, `sp_id`, `user_name`, `user_img`, `msg`) VALUES
(1, 1, 'nikunj', 'rguser_img/58db54511478a.png', 'This is good food provaider'),
(2, 1, 'nikunj', 'rguser_img/58db54511478a.png', 'good Gujarati items provid');

-- --------------------------------------------------------

--
-- Table structure for table `user_order_address`
--

CREATE TABLE IF NOT EXISTS `user_order_address` (
  `address_id` int(200) NOT NULL,
  `user_email` varchar(200) NOT NULL,
  `sp_id` int(200) NOT NULL,
  `order_id` int(200) NOT NULL,
  `Street_address` varchar(200) NOT NULL,
  `street` varchar(200) NOT NULL,
  `city` varchar(200) NOT NULL,
  `state` varchar(200) NOT NULL,
  `pincoad` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Complite_delivery_detail`
--
ALTER TABLE `Complite_delivery_detail`
  ADD PRIMARY KEY (`c_d_id`);

--
-- Indexes for table `D_registraion`
--
ALTER TABLE `D_registraion`
  ADD PRIMARY KEY (`Del_id`);

--
-- Indexes for table `Ragistration`
--
ALTER TABLE `Ragistration`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `food_order`
--
ALTER TABLE `food_order`
  ADD PRIMARY KEY (`sr_no`);

--
-- Indexes for table `food_order_detail`
--
ALTER TABLE `food_order_detail`
  ADD PRIMARY KEY (`f_d_id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`img_id`);

--
-- Indexes for table `offer`
--
ALTER TABLE `offer`
  ADD PRIMARY KEY (`offer_id`);

--
-- Indexes for table `payment_detail`
--
ALTER TABLE `payment_detail`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `sp_ragistration`
--
ALTER TABLE `sp_ragistration`
  ADD PRIMARY KEY (`sp_id`);

--
-- Indexes for table `tiffin_categaries`
--
ALTER TABLE `tiffin_categaries`
  ADD PRIMARY KEY (`tc_id`);

--
-- Indexes for table `tiffin_items`
--
ALTER TABLE `tiffin_items`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `user_msg`
--
ALTER TABLE `user_msg`
  ADD PRIMARY KEY (`msg_id`);

--
-- Indexes for table `user_order_address`
--
ALTER TABLE `user_order_address`
  ADD PRIMARY KEY (`address_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Complite_delivery_detail`
--
ALTER TABLE `Complite_delivery_detail`
  MODIFY `c_d_id` int(200) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `D_registraion`
--
ALTER TABLE `D_registraion`
  MODIFY `Del_id` int(200) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `Ragistration`
--
ALTER TABLE `Ragistration`
  MODIFY `user_id` int(200) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `food_order`
--
ALTER TABLE `food_order`
  MODIFY `sr_no` int(200) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT for table `food_order_detail`
--
ALTER TABLE `food_order_detail`
  MODIFY `f_d_id` int(200) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `img_id` int(200) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `offer`
--
ALTER TABLE `offer`
  MODIFY `offer_id` int(200) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `payment_detail`
--
ALTER TABLE `payment_detail`
  MODIFY `payment_id` int(200) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `sp_ragistration`
--
ALTER TABLE `sp_ragistration`
  MODIFY `sp_id` int(200) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tiffin_categaries`
--
ALTER TABLE `tiffin_categaries`
  MODIFY `tc_id` int(200) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tiffin_items`
--
ALTER TABLE `tiffin_items`
  MODIFY `item_id` int(200) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `user_msg`
--
ALTER TABLE `user_msg`
  MODIFY `msg_id` int(200) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `user_order_address`
--
ALTER TABLE `user_order_address`
  MODIFY `address_id` int(200) NOT NULL AUTO_INCREMENT;--
-- Database: `upload`
--

-- --------------------------------------------------------

--
-- Table structure for table `img`
--

CREATE TABLE IF NOT EXISTS `img` (
  `Img_ID` int(3) NOT NULL,
  `Image` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `img`
--

INSERT INTO `img` (`Img_ID`, `Image`) VALUES
(1, 'images/5847a17814f87.png'),
(2, 'images/5847afdcabf23.png'),
(3, 'images/5847b12c4f9bd.png'),
(4, 'images/5847b1533e314.png'),
(5, 'images/584f9edbb79ee.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `img`
--
ALTER TABLE `img`
  ADD PRIMARY KEY (`Img_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `img`
--
ALTER TABLE `img`
  MODIFY `Img_ID` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
